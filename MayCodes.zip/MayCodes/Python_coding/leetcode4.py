def findMedianSortedArrays(nums1, nums2):
        comlist = nums1 + nums2
        comlist.sort()
        l = len(comlist)
        if l % 2 != 0:
            index = l//2
            median = comlist[index]
        else:
            index = l//2
            index2 = index - 1 
            median = (comlist[index2] + comlist[index])//2
        print(median)
        return median
findMedianSortedArrays([1,3], [2])