zypper install libopenssl-devel
zypper install libffi-devel
zypper install zlib-devel
zypper install uuid
zypper install bzip2
zypper install lzma-sdk-devel
zypper install tk-devel
zypper install readline-devel
zypper install gdbm-devel
zypper install uuid-devel
zypper install yast2-nis-server

make 
make altinstall
pip3.9 install gnureadline

zypper install python3-readline
  121  2023-07-27 01:34:03 pip install pyreadline3
  122  2023-07-27 01:34:10 python3.9
  123  2023-07-27 01:34:23 pip3.9 install pyreadline3
  124  2023-07-27 01:34:58 ln -s /usr/local/lib64/python3.9/lib-dynload/ /usr/local/lib/python3.9/lib-dynload
  125  2023-07-27 01:34:59 pip3.9 install pyreadline3
  126  2023-07-27 01:35:12 pip3.9 install readline
  127  2023-07-27 01:39:08 pip3.9 install gnureadline


_bz2                  _lzma                 _uuid
nis
                         
#40C7BB