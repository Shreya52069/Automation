def isPalindrome(self, x: int) -> bool:
    y = str(x)
    l=0
    r=len(y)-1
    while l<r:
            if y[r] == y[l] and r != l:
                l = l+1
                r = r-1
            if y[r] != y[l] and r != l:
                return False
    return True