def decode(n):
    dplen = len(n) + 1
    dp = [0] * dplen
    dp[0] = 1
    dp[1] = 1 if n[0] != '0' else 0
    for i in range(2,dplen):
        if n[i-1] != '0':
            dp[i] += dp[i-1]
        if n[i-1] == '0' and n[i-2] in '0123456':
            dp[i] += dp[i-1]
        else:
            dp[i] = dp[i-1]+dp[i-2]
    return dp[-1]
print(decode('122016'))