class Node:
    def __init__(self, value, left=None, right=None):
        self.value = value
        self.right = right
        self.left = left
    def __str__(self):
        return "Node("+str(self.value)+")"
def walk(tree, stack): #iterative
    stack.append(tree)
    while len(stack) > 0:
        n = stack.pop()
        if n != None:
            print(n)
            stack.append(n.right)
            stack.append(n.left)
def walk2(tree):
    if tree is not None:
        #pre-order
        print(tree)
        walk2(tree.left)
        walk2(tree.right)
mytree = Node('A',Node('B', Node('D'), Node('E')), Node('C', Node('F'), Node('G')))
print(walk(mytree, []))
print(walk2(mytree))
print(mytree)