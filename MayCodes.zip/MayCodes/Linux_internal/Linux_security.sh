File permissions-
type(dir, file, syboliclink) owner Group public
drwxr-x-r-x Ownerofthefile groupownerofthefile 

r = 4
w = 2 
x = 1


