import string
def cleanline(line):
    return ''.join([char for char in line if char not in string.punctuation])
print(cleanline("Helko!! It will be great. ok!"))

def word_count(filepath):
    wordcount = {}
    f  = open(filepath, 'r')
    for line in f:
        for word in cleanline(line).split():
            if word in wordcount:
                wordcount[word] += 1
            else:
                wordcount[word] = 1
    print(wordcount)
word_count("/Users/shreya.bhardwaj/Downloads/MayCodes/pythoncode/subprocess.py")
       
