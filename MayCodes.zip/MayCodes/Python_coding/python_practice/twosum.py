def twosum(sum, arr):
    seen = {}
    for i in range(len(arr)):
        diff = sum - arr[i]
        if diff in seen:
            return [seen[diff], i]
        else:
            seen[arr[i]] = i
    return -1

print(twosum(10,[2,5,6,8,9]))