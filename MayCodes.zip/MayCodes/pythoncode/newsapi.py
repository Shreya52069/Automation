import requests
import json
from bs4 import BeautifulSoup
#from newsapi import NewsAPiClient

class NewsRequests:
    api_key = "7882a63a0e254caf95b4aac7f8f425c1"
    def __init__(self, topic, name):
        self.topic = topic
        self.name = name

    def req(self):
        
        #url = "https://newsapi.org/v2/"+self.topic+"?country=in&apiKey="+self.api_key
        url1 = f"https://newsapi.org/v2/{self.topic}?country=in&apiKey={self.api_key}"
        url = f"https://newsapi.org/v2/everything?q={self.topic}&from=2023-08-04&sortBy=popularity&apiKey=7882a63a0e254caf95b4aac7f8f425c1"
        res = requests.get(url)
        news = json.loads(res.text)
        for i in news["articles"]:
            print(i["author"])

if __name__ == "__main__":
    name = input("May I know you name? \n")
    topic = input(f"Hey {name}. Which topic of news would you like to know about?\n")
    reqobj = NewsRequests(topic, name)
    reqobj.req() 