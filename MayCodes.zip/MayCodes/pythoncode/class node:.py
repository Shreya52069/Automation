class node:
    def __init__(self, data, next=None):
        self.data = data
        self.next = next
class ll:
    def __init(self):
        self.head = None
    def insertatbegin(self, data):
       newnode = node(data, self.head)
       self.head = newnode
    def print(self):
        if self.head == None:
            print("empty")
            return
        llpr = ''
        itr = self.head
        while itr:
            llptr += str(itr.data)+'--->'
            itr = itr.next
        print(llpr)

    def size(self):
        if self.head == None:
            print("empty")
            return 0
        itr = self.head
        count = 0
        while itr:
            count += 1
            itr = itr.next
        return count
    def insertatindex(self, data, index):
        if index > self.size() or index < 0:
            raise Exception("Invalid index")
        if index == 0:
            self.insertatbegin(data)
            return
        count = 0
        itr =self.head
        while itr:
            if count == index - 1:
                newnode = node(data, itr.next)
                itr.next = newnode
                break
            count += 1
            itr = itr.next
    def insertatend(self, data):
        if self.head == None:
            self.insertatbegin(data)
            return
        itr = self.head
        while itr:
            itr = itr.next
        newnode = node(data, None)
        itr.next = newnode
    
    def removeatbegin(self):
        if self.head == None:
            return
        self.head = self.head.next
    def removeatend(self):
        if self.head  == None:
            return
        itr = self.head
        while itr.next.next:
            itr = itr.next
        itr.next = None
    
    def removeatindex(self, index):
        if self.size < index or index < 0:
            raise Exception("invalid index")
        if self.head == None:
            print("empty ll")
            return
        itr = self.head
        count = 0
        while itr:
            if count == index - 1:
                itr.next = itr.next.next
                break
            count += 1
            itr = itr.next
    def updatenode(self, data, index):
        if index > self.size or index < 0:
            raise Exception("invalid index")
        if index == 0:
            self.head.data = data
            return
        itr = self.head
        count = 0
        while itr:
            if count == index:
                itr.data = data
                break
            count += 1
            itr = itr.next
    def removedata(self, data):
        itr = self.head
        while itr:
            if itr.next.data == data:
                itr.next = itr.next.next
                break
            itr = itr.next
    
