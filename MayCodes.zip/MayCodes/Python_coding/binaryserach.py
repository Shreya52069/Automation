def binarysearch(data, target):
    low = 0
    high = len(data)-1
    while low <= high:
        mid = (low+high)//2
        if target == data[mid]:
            return True
        if target < data[mid]:
            high = mid -1
        else:
            low = mid + 1
    return False
print(binarysearch([1,4,6,8,9,11,34,56], 11))

def binaryrecursive(data, target, low, high):
    if low > high:
        return False
    else:
        mid = (low+high)//2
        if target > data[mid]:
            binaryrecursive(data, target, mid+1, high)
        elif target < data[mid]:
            binaryrecursive(data, target, low, mid-1)
        elif target == data[mid]:
            return True