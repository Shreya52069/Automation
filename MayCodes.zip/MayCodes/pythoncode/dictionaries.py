def dict1():
    purse = dict()
    #order is not maintained in the dictionaries
    purse['money'] = 1202902
    purse['candy'] = 3
    purse['keys'] = 1
    purse['tissues'] = 10
    print(purse)
    co = {}
    #counting number of elemets in a list
    names= ['csev', 'cwen', 'csev','zquian','cwen']
    for name in names:
        if name not in co:
            co[name] = 1 #key is name and value is 1
        else:
            co[name] = co[name]+1

    print(co)

    name = 'csev'
    if name in co: #this is what get method does- here we are simply picking value from the dictionary
        x = co[name]
    else:
        x = 0
    print(x)
    namedict = {}
    print("correct val")
    for name in names:
        # co[name] = co.get(name,0) +1  - this is just picking the value of the key
         # this should be this-
         namedict[name] = namedict.get(name,0)+1 #in get function 0 is default 
         print(namedict)
    # count number of words in a file

    linewords = {}
    line = "Hi. My name is Shreya Bhardwaj. I'm sure you know that by this time"
    words = line.split()
    for word in words:
        linewords[word] = linewords.get(word, 0)+1
    print(linewords)

    for key in linewords:
        print(key,linewords[key])

    list(linewords)
    print(list(linewords))
    print(linewords.keys())
    print(linewords.values())
    print(linewords.items())

    for i,j in linewords.items():
        print(i,j)
    

dict1()

#Tuples- ()- immutable- but lists are mutable- cannot use sort, append, reverse() in tuples
def tuples():

    x = ('glen','toit','grey')
    print(x[2])

    # we can put a tuple on left hand and assign items on right side
    (y,z) = (4,'dongle') # here, y will be 4 and z will be dongle

    #similarly we can compare as well
    print((0,6,7) < (1,5,9))# this returns true or false- only first item is compared
    print((0,1,2000)<(0,3,4)) # here second item is compared as well
    print(('jones', 'sally') < ('jones', 'sam'))

    #We can append list of tuples
    d = {'a':10, 'b':6, 'e': 8}
    print(sorted(d.items())) # sorted function will print list of tuples of dictionary KEY,VALUE IMPORTANT -[('a', 10), ('b', 6), ('e', 8)]
    f = list()
    for k,v in d.items():
        f.append((k,v)) #list of tuple
    print(f)
    f = sorted(f, reverse=True)
    print(f)

    m = sorted(d.items())
    print(m)
    n = sorted(m, reverse=True)
    print(n)
tuples()

def commas():
    str1 = "Hello Shreya, you are the best, you can do better shreya. The best you can do is be better."
    list1 = str1.split()
    dic1 = {}
    for word in list1:
        w = word.casefold()
        if "," in w:
            w = w.rstrip(',')
        dic1[w] = dic1.get(w,0)+1
    print(dic1)
#commas()
def keyss():
    dict2 = {"d1":10, "d2":20, "d3": 30}
    for i in dict2.keys():
        dict2[i] = dict2[i] + 1 
    print(dict2)

keyss()