def reverseVowels(self, s: str) -> str:
        l = 0 
        r = len(s)-1
        slist = list(s)
        vowels = 'aeiouAEIOU'
        while l < r:
            if slist[l] in vowels and slist[r] in vowels:
                slist[l], slist[r] = slist[r], slist[l]
                l +=1
                r -= 1
            elif slist[l] in vowels and slist[r] not in vowels:
                r -= 1
            elif slist[l] not in vowels and slist[r] in vowels:
                l += 1
            else:
                r -= 1
                l += 1
        news = ''.join(slist) 
        return news