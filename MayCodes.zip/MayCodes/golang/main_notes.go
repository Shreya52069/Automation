Infra changed a lot - became multicore, cloud came in- scalable, more capacity
We want to run multiple processes in parallel
Concurrency is cheap and easy in go lang
Docker, K8S, cockroach DB, vault - all are written in go
Easy syntax, fast built time
Complies in a single binary (complied) unlike python which runs line by line (intepreted)

Installed easily using a installer.
Import go extension in vscode

File Structure- 
1. one main file for the project- main.go
2. We need to make our go application into a project - basicallyu intialize the project using-
#go mod init <name of the project>

#go mod init booking-app

When we run the above command a go.mod file is created with name/module path and go version

In go everything is organised into packages. All syntx needs diff packages.

package main
func main(){

}

Go needs to know whats the entrypoint of the application. The main starting point where the execution starts.
1 program can have 1 "main" function.

package main
import fmt
func main(){
	fmt.Print("hello world")
	fmt.Println("hi")
}

#go run main.go
------------------------------
Variables and constants

Go has 25 reserved keywords.
To declare a variable:
var name = "shreya"
var conferenceName = "Go conference"

To declare contanst- const

package main
impor fmt
func main(){
	var.conferenceName = "Go conference"
	const conferenceTickets = 50
	var remainingTickets = 50
	fmt.Println("Welcome to",conferenceName, "booking application")
	fmt.Println("We have total of", conferenceTickets, "tickets and", remainingTickets, "are still available")
	fmt.Println("Get your tickets here to attend")
}

printf - used to print formated data
fmt.Printf("Some text with a variable %v", myVariable)

It takes a template string that contains the text that needs to be formatted.
fmt.Printf("Welcom to %v booking application\n", conferenceName)

%v - variable
----------------------------------
Defining a variable and assiging the value later.

var userName string
//ask user for their input
var userTickets int

userName = "Tom"
userTickets = 2

Data types
	string
	int - int8 (btye) int16(short) int32(int) int64(long) uint -whole numbers(only positive ints)
	float - float32 32-bit floating-point numbers, float64 64-bit floating-point numbers
	Booleans
	Maps
	Arrays

To print the type of the variable - %T
fmt.Printf("conferenceTickets is %T", conferenceTickets)

Another way of assinging variables := 
conferenceName := "Go Confernece"

-----------------------------
To ask user to input  - fmt.Scan() - uses a pointer.
varibale - tickets 
pointers - &tickets ---> pointing to the memory address  
fmt.Print(&remainingTickets) - this will print the memory location of the variable

var userName
fmt.Scan(&userName)
Scan function can now assign the users value to the userName variable as it has a pointer to the memory address
basically means Scan(0xc00124)

fmt.Println("Enter your first name:")
fmt.Scan(&userName)

package main
import fmt
func main(){
	conferenceName := "Go conference"
	const conferenceTickets = 50
	var remainingTickets uint = 50
	fmt.Println("Welcome to",conferenceName, "booking application")
	fmt.Println("We have total of", conferenceTickets, "tickets and", remainingTickets, "are still available")
	fmt.Println("Get your tickets here to attend")
	var firstName string
	var lastName string
	var email string
	var userTickets uint

	fmt.Println("Enter your first name:")
	fmt.Scan(&firstName)
	fmt.Println("enter you lastname:")
	fmt.Scan(&lastName)
	fmt.Println("Enter you email:")
	fmt.Scan(&email)
	fmt.Println("How many tickets you wish to buy?")
	fmt.Scan(&userTickets)

	remainingTickets = remainingTickets - userTickets // issue will come if remainingTickets is uint and userTicket is int

	fmt.Println("Thank you %v %v for booking %v tickets. You will receieve the ticket on your email %v\n", firstName, lastName, userTickets, email)

}
----------------
Array and Slices in Go:

arrays- in go have fixed size 

var nameOfArray = [size of array]Type{empty array}
var bookings = [50]string{"Nana", "Ash", "swati"}

To declare an array without any value-  var bookings [50]string
bookings[0] = "Nana"
bookings[10] = "Shreya"

bookings[0] = firstName+ " " +lastName

//Note: you can use a variable after it is defined.
fmt.Printf("The whole array: %v\n", bookings)
fmt.Printf("The first value of array: %v\n", bookings[0])
fmt.Printf("The type of array: %T\n", bookings[0])
fmt.Printf("The lenght of array: %v\n", len(bookings))

Problem with array- sometimes we dont want to define the size, we might dont know what will be the size.
Slice is abstration of array and has a dynamic size.
In "Slice" we dont need to use the index. We can directly use append, remove methods. 
append adds the element at the end of the slice.

var sliceVari []string
sliceVari  = append(SliceVari, firstName + " " +lastName)
fmt.Printf("The first value: %v\n", sliceVari[0])

----------
Loops in go

We dont have many loops like while, for-each etc we only have for loop in go

infinite loop- 
for {
	var firstName string
	var lastName string
	var email string
	var userTickets uint

	fmt.Println("Enter your first name:")
	fmt.Scan(&firstName)
	fmt.Println("enter you lastname:")
	fmt.Scan(&lastName)
	fmt.Println("Enter you email:")
	fmt.Scan(&email)
	fmt.Println("How many tickets you wish to buy?")
	fmt.Scan(&userTickets)

	remainingTickets = remainingTickets - userTickets // issue will come if remainingTickets is uint and userTicket is int
	bookings[0] = firstName + " " + lastName

	fmt.Printf("The whole array: %v\n", bookings)
	fmt.Printf("The first value of array: %v\n", bookings[0])
	fmt.Printf("The type of array: %T\n", bookings[0])
	fmt.Printf("The lenght of array: %v\n", len(bookings))
	fmt.Printf("Thank you %v %v for booking %v tickets. You will receieve the ticket on your email %v\n", firstName, lastName, userTickets, email)
}

for-each loop-

firstname := []string //this is a slice
for index, booking := range bookings //for loops uses 2 things- index and the value itself. 

//Range expressions is used to iterate over elements for different data structures. Not only arrays and slices. 
//But for slices and arrays specifically it gives back index and value for each element
import (
	"fmt"
	"strings"
)
for {
	var firstName string
	var lastName string
	var email string
	var userTickets uint

	fmt.Println("Enter your first name:")
	fmt.Scan(&firstName)
	fmt.Println("enter you lastname:")
	fmt.Scan(&lastName)
	fmt.Println("Enter you email:")
	fmt.Scan(&email)
	fmt.Println("How many tickets you wish to buy?")
	fmt.Scan(&userTickets)

	remainingTickets = remainingTickets - userTickets // issue will come if remainingTickets is uint and userTicket is int
	bookings[0] = firstName + " " + lastName

	fmt.Printf("The whole array: %v\n", bookings)
	fmt.Printf("The first value of array: %v\n", bookings[0])
	fmt.Printf("The type of array: %T\n", bookings[0])
	fmt.Printf("The lenght of array: %v\n", len(bookings))
	fmt.Printf("Thank you %v %v for booking %v tickets. You will receieve the ticket on your email %v\n", firstName, lastName, userTickets, email)
	firstnames := []string
	for index, booking := range bookings {
		var names = strings.Fields(booking) // Fields function comes from string package and splits the string with white space as separator and returns a slice with the split elements. 
		//"Nicole Smith"  ->  ["Nicole", "Smith"]
		var firstName = names[0]
		firstNames = append(firstNames, firstName)
	}
	fmt.Printf("The first names of bookins are: %v\n", firstNames)
}
//in the above logi we are not using the variable index anywhere because we dont need that value 
//instead of that variable we can use _ it is uded to ignore a variable dont want to use
for _, booking := range bookings {
	}

----------------------
Conditionals-

1. if loop

if remainingTickets == 0 {
	//end
	fmt.Println("our conferene is booked out")
	break
}

or

var noTicketsRemaining bool = remainingTickets == 0
if noTicketsRemaining {
	break
}

if userTickets > remainingTickets {
	fmt.Printf("We only have %v tickets remaining, so you can't book %v tickets\n", remainingTickets, userTickets)
	break
}

if userTickets <= remainingTickets {
	.....booking code
}
else {
	fmt.Printf("We only have %v tickets remaining, so you can't book %v tickets\n", remainingTickets, userTickets)
}

if userTickets < remainingTickets {

}
else if userTickets == remainingTickets {

}
else {

}

for loop with a condition- 

for remainingTickets > 0 && len(bookings) < 50 {

}
------------------
Validating user input- 

var isValidName bool = len(firstName) >= 2 && len(lastname) >= 2
var isValidEmail bool = strings.Contains(email, "@")
isValidTickets  := userTickets > 0  && userTickets <= remainingTickets
isValidcity := city == "Singapore" || city =="London"
ifInvalidCity := city != "Singapore" && city != "London" =--> !isValidcity

if isValidName && isValidEmail && isValidTickets {
	....booking logic
}
else {
	if !isValidName {
		fmt.Println("first name or last name you endered is too short")
	}
	if !isValidEmail {
		fmt.Println("email address doesnt not contain @ sign")
	}
	if !isValidTickets {
		fmt.Println("Number of tickets is invalid")
	}
}
--------------------
Switch statement-

example: We want to execute booking code depending on which city user chooses:

city := "London"
switch city {
	case "New york":
		// code for new york
	case "London", "Berlin":
		//code
	case "Singapore", "Hong Kong":
		//
	default:
		fmt.Print("No valid city selected")
}
----------------------
Functions: to encapsulate code.
outside of main func
func greetUsers(){
	fmt.Println("Welcome to out conference")
}

call funtion inside the main function

func main(){
	greetUsers()
}
 
With parameters:

func main(){
	var conferenceName := "Go Conference"
	greetUsers(conferenceName)
}
func greetUsers(confName string){
	fmt.Printf("Welcome to %v booking application", confName)
}
