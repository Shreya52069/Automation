#starting in the middle and going outwards 
def longestPalindrome(s):
    result = ""
    resultLen = 0
    for i in range(len(s)): #going through every position- thinking it is the center of a palindrome
        #odd length
        l, r = i, i # this are pointes for left and right
        while l >= 0 and r < len(s) and s[l] == s[r]:
            if(r-l+1) > resultLen:
                result  = s[l:r+1]
                resultLen = len(result)
            l -= 1
            r += 1
        #even length
        l, r = i, i+1
        while l >= 0 and r < len(s) and s[l] == s[r]:
            if(r-l+1) > resultLen:
                result  = s[l:r+1]
                resultLen = len(result)
            l -= 1
            r += 1
    return result