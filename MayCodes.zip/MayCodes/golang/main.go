package main

import (
	"fmt"
	"strings"
)

func main() {
	conferenceName := "Go conference"
	const conferenceTickets = 50
	var remainingTickets uint = 50
	var bookings []string
	greetUsers(conferenceName, conferenceTickets, remainingTickets)
	//fmt.Println("Welcome to", conferenceName, "booking application")
	//fmt.Println("We have total of", conferenceTickets, "tickets and", remainingTickets, "are still available")
	//fmt.Println("Get your tickets here to attend")
	for {
		var firstName string
		var lastName string
		var email string
		var userTickets uint

		fmt.Println("Enter your first name:")
		fmt.Scan(&firstName)
		fmt.Println("enter you lastname:")
		fmt.Scan(&lastName)
		fmt.Println("Enter you email:")
		fmt.Scan(&email)
		fmt.Println("How many tickets you wish to buy?")
		fmt.Scan(&userTickets)
		var isValidName bool = len(firstName) >= 2 && len(lastName) >= 2
		var isValidEmail bool = strings.Contains(email, "@")
		isValidTickets := userTickets > 0 && userTickets <= remainingTickets

		if isValidEmail && isValidName && isValidTickets {
			if userTickets > remainingTickets {
				fmt.Printf("We only have %v tickets remaining, so you can't book %v tickets\n", remainingTickets, userTickets)
				continue // this will go to next iteration of the loop.
			}

			remainingTickets = remainingTickets - userTickets // issue will come if remainingTickets is uint and userTicket is int
			bookings[0] = firstName + " " + lastName

			fmt.Printf("The whole array: %v\n", bookings)
			fmt.Printf("The first value of array: %v\n", bookings[0])
			fmt.Printf("The type of array: %T\n", bookings[0])
			fmt.Printf("The lenght of array: %v\n", len(bookings))
			fmt.Printf("Thank you %v %v for booking %v tickets. You will receieve the ticket on your email %v\n", firstName, lastName, userTickets, email)

			printFristNames(bookings)
			firstNames := returnPrintFristNames(bookings)
			fmt.Printf("The first names of bookings are: %v\n", returnFirstNames)

			firstNames := []string{}
			for _, booking := range bookings {
				var names = strings.Fields(booking) // Fields function comes from string package and splits the string with white space as separator and returns a slice with the split elements.
				//"Nicole Smith"  ->  ["Nicole", "Smith"]
				var firstName = names[0]
				firstNames = append(firstNames, firstName)
			}
			fmt.Printf("The first names of bookins are: %v\n", firstNames)
			if userTickets > remainingTickets {
				fmt.Printf("We only have %v tickets remaining, so you can't book %v tickets\n", remainingTickets, userTickets)
				break
			}

			if remainingTickets == 0 {
				fmt.Println("our conferene is booked out")
				break
			}
		} else {
			if !isValidName {
				fmt.Println("first name or last name you endered is too short")
			}
			if !isValidEmail {
				fmt.Println("email address doesnt not contain @ sign")
			}
			if !isValidTickets {
				fmt.Println("Number of tickets is invalid")
			}
		}
	}
}
func greetUsers(confName string, confTickets int, remainingTickets uint) {
	fmt.Printf("Welcome to %v booking application", confName)
	fmt.Printf("We have total of %v tickets and %v are still available.\n", confTickets, remainingTickets)
	fmt.Println("Get your tickets here to attend.")
}
func printFristNames(bookings []string) {
	firstNames := []string{}
	for _, booking := range bookings {
		var names = strings.Fields(booking)
		firstNames = append(firstNames, names[0])
	}
	fmt.Printf("The first names of bookings are: %v\n", firstNames)
}
func returnPrintFristNames(bookings []string) []string { //func name(input parameter) output paramater - basically what you want to return.- here firstNames is also a slice of string.
	returnFirstNames := []string{}
	for _, booking := range bookings {
		var names = strings.Fields(booking)
		returnFirstNames = append(returnFirstNames, names[0])
	}
	return returnFirstNames
}

func validateUserInput()
