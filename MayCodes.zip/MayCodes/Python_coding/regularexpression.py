def isMatch(self, s: str, p: str) -> bool:
        if len(s) >=20 or len(p) >=20:
            return -1
        for i in range(len(s)):
            if s[i] == p[i] or p[i] == '.' or p[i] == *:
                return True
            else:
                return False