import string
def patt(num):
    for i in range(num):
        print(i)
def stringabddict():
    Line = "Hello Shreya, Please try to practice scripting more please try shreya."
    cleanLine = ''.join(wor for wor in Line if wor not in string.punctuation)
    d = {}
    for word in cleanLine.split():
        w = word.lower()
        if w not in d:
            d[w] = 1
        else:
            d[w] =  d[w] + 1
    print(d)
stringabddict()
