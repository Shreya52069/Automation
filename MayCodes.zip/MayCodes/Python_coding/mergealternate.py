def mergeAlternately(self, word1: str, word2: str) -> str:
        res = ''
        k = min(len(word1), len(word2))
        j = max(len(word1), len(word2)) 
        h = len(word1)
        d = len(word2)
        i=0
        while i < k:
            res += word1[i]+word2[i]
            i += 1
        if h > d:
            res += word1[k:j]
        if d > h:
            res += word2[k:j]
        return res