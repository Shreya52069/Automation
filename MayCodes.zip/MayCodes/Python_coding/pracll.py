class Node:
    def __init__(self, data, next):
        self.data = data
        self.next = next
class ll:
    def __init__(self):
        self.head = None
    def insertatbegin(self, data):
        newnode = Node(data, self.head)
        self.head = newnode
    def print(self):
        itr = self.head
        while itr:
            print(itr+"--->")
            itr = itr.next
    def removeatbeing(self):
        if self.head == None:
            return 
        self.head = self.head.next
    def insertatend(self, data):
        itr = self.head
        while itr.next:
            itr = itr.next
        itr.next = Node(data, None)

    def size(self):
        itr = self.head
        sizecount = 0
        while itr:
            sizecount +=1 
            itr = itr.next
        return sizecount
    def insertatindex(self, data, index):
        if index > self.size() or size < 0:
            raise Exception("invalid index")
        if index  == 0:
            self.insertatbegin(data)
        itr = self.head
        count = 0
        while count < index:
            if count == index - 1:
                newnode = Node(data, itr.next)
                itr.next = newnode 
                break
            itr = itr.next
            count += 1
    def removeatend(self):
        itr = self.head
        while itr.next:
            itr = itr.next
        itr.next = None

    def removeatindex(self, index):
        if index > self.size() or size < 0:
            raise Exception("invalid index")
        if index  == 0:
            self.removeatbeing()
        itr = self.head
        count = 0
        while count < index:
            if count == index - 1:
                itr.next = itr.next.next
                break
            itr = itr.next
            count += 1
    def removeatend(self):
        itr = self.head
        while itr.next.next:
            itr = itr.next
        itr.next = None
    def updatedata(self, data, index):
        if index > self.size() or index < 0:
            raise Exception("invalid index")
        if index  == 0:
            self.head.data = data
        itr = self.head
        count = 0
        while itr:
            if count == index:
                itr.data =  data
                break
            count +=1
            itr = itr.next
                
    def removedata(self, data):
        itr = self.head
        while itr:
            if itr.next.data == data:
                itr = itr.next.next
                break
            itr = itr.next

class doublenode:
    def __init__(self, prev, data, next):
        self.prev = prev
        self.data = data
        self.next = next
class doubell:
    def __init__(self):
        self.head = None
        