def fibo(n):
    z = []
    if n == 0:
        return 0
    if n == 1:
        return 1
    else:
        for i in range(n):
            if i == 0:
                z.append(0)
            elif i == 1:
                z.append(1)            
            else:
                z.append(z[i-1] + z[i-2])
        return z
print(fibo(20))

def fact(n):
    if n == 0 :
        return 1
    elif n == 1:
        return 1
    else:
        x = n * fact(n-1)
        return x
print(fact(10))

from functools import reduce
numbers = [1,2,5,7]
sum = reduce(lambda x,y: x+y, numbers)
print(sum)
