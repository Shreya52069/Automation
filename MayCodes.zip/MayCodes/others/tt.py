string = "geeks quiz practice code"
#reversing words in a given string
s = string.split()[::-1]
print(s)
l = []
for i in s:
    #appending reversed words to l
    l.append(i)
# printing reverse words
print(" ".join(l))
print()

test_str = "GeeksForGeeks"
new_str = test_str.replace('e', '')
print(test_str[:1])
print(test_str[3:])
print(dir(test_str))



#navjeevan (avni fashions)- saraogi
#sikar house
#suryavanshi- tonk road.

