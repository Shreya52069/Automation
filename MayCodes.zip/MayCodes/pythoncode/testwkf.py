def sen(txt):
    stemmed_words = []
    for word in txt.split():
        if word.endswith("ed"):
            stemmed_word = word[:-2]
        elif word.endswith("ly"):
            stemmed_word = word[:-2]
        elif word.endswith("ing"):
            stemmed_word = word[:-3]
        else:
            stemmed_word = word[:8]
        stemmed_words.append(stemmed_word)
    # Join the stemmed words to form the modified sentence
    sentence = ' '.join(stemmed_words)
    return sentence

# Call the function and print the modified sentence
modified_sentence = sen("a boy jumped quickly in boxing")
print(modified_sentence)
