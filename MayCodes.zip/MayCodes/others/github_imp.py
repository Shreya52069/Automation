import git
#git.Repo.clone_from('https://github.com/dimagi/commcare-hq', 'C:\Shreya_personal\Python\MayCodes\comcaree')
git.Repo.clone_from('https://github.com/dimagi/commcare-hq/tree/master/corehq/apps/hqwebapp/static/hqwebapp/images', 'C:\Shreya_personal\Python\MayCodes\comcaree\comcareeimages')

#git multibranching pipeline strategy. 
#Developer commits- webhooks- jenkins pipeline- end image to hub- 
# how to you identify what is your prod, dev, test environments
#how do you manage multiple aws accounts- 
#steps to take for cost optimizations.
#VPc- private network inside the public cloud-- 
#public subnet, private subnet, NAT gateway
#how will I get my app logs from ec2 to cloudwatch logs?
# lambda service- lambda functions?
#What is high availabilty and how do you achieve that?
#Security best practices that you have implementted in your project- 
    security groups(allow rules), NACLs(aLlow, deny rules), proper IAM permissions, IAM policies, WAF, multifactor authentication, blackduck, 
#What info do you get from sonarqube?
#customers having issue about DB?- what will you do?
#

Developer settings- Personal access tokens- generate token- add to git. 