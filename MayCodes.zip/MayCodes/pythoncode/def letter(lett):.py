def letter(lett):
    fruit = lett
    for i in range(len(fruit)):
        lette = fruit[i]
        print(lette)
letter("apple")

linewords = {}
line = "Hi. My name is Shreya Bhardwaj. I'm sure you know that by this time"
words = line.split()
for word in words:
    linewords[word] = linewords.get(word, 0)+1
print(linewords)

for key in linewords:
    print(key,linewords[key])

list(linewords)
print(list(linewords))
print(linewords.keys())
print(linewords.values())
print(linewords.items())

for i,j in linewords.items():
    print(i,j)

def ref(mylist,x):
    print(mylist)
    x = 2 # this is local variable- gets destroyed
    print(x)
    mylist[2] = 40
    print(mylist)
    return
mylist = [10,20,70,50]
x =10
ref(mylist,x)
print(mylist)
print(x)
def prime1():
    x = 3
    while x != 0:
        x = int(input("input the number: "))
        for i in range(2,x):
            if x % i == 0:
                print("{} is not a prime number".format(x))
                break
        else:
            print("prime")
prime1()