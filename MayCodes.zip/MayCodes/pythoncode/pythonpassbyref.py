def ref(mylist,x):
    print(mylist)
    x = 2
    print(x)
    mylist[2] = 40
    print(mylist)
    return
mylist = [10,20,70,50]
x = 10
ref(mylist,x) # we have passed x=10, but inside function we have changed the value of it. 
print(mylist) # here the new list is printed- hence the change made by fucntion is also reflected
print(x) #but outside it is the same as 10

class test:
    def __init__(self, x):
        self.x = x
        print(x)
    def change(self):
        self.x = 7
        print('this is the gloabl x', x)
        print('this is the changed self.x in function', self.x)
    print('this is bkah:', x) # this picks global x value which si provided above =10
    def p(self):
        print(self.x)
obx = test(9)
obx.change()
obx.p()
a=8
b=9
print("A") if a > b else print("=") if a == b else print("B")