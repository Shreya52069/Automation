#!/bin/bash
echo "Shell scripting is fun"
SHELL_VAR="Shell Scripting is fun"

SERVER=$(hostname)
echo "The script is running on ${SERVER} where ${SERVER} is the output of the 'hostname' command "

if [-e /etc/shadow]
then   
    echo "Shadow passwords are enabled"
fi
if [-w /etc/shadow]
then
    echo "You have permissions to edit /etc/shadow."
else
    echo "You do NOT have permissions to edit /etc/shadow"
fi

for animal in man bear pig dog create
do
    echo $animal
done

read -p "Enter the filename or directory name: " NAME
if [-d $NAME]
then
    echo "This is directoy"
    ll $N
elif [-f $NAME]
then
    echo "It is a regular file"
    cat $NAME
else
    echo "It is not a regular file"
fi

for NAME in $@
do
    echo "Checking if $NAME is a directory, regular file or other type of file:"
    if [-d $NAME]
    then
        echo "This is directoy"
        ll $NAME
    elif [-f $NAME]
    then
        echo "It is a regular file"
        cat $NAME
    else
        echo "It is not a regular file"
    fi
done

#!/bin/bash

hostname
if [ "$?" -eq "0" ]
then
        echo "Exiting with 0 exit status"
else
        echo "Exiting with 1"
fi
read -p "enter the file name: " FILE
if [ -f $FILE ]
then
        echo "Regular file"
        exit 0
elif [ -d $FILE ]
then
        echo "Directory"
        exit 1
else
        echo "Other type of file"
        exit 2
fi
