import java.time.*
import java.time.format.DateTimeFormatter
@Library('jenkins-pipeline-lib')_

def buildParameters = [
    string(defaultValue: '', name: 'BRANCH_NAME', trim: true),
    choice(
        choices: [
            'credit-01-scv.stg.whizdmfinance.com|credit-01',
        ],
        name: 'DEPLOY_INFO',
        description: '''APP_URL: credit-01-scv.stg.whizdmfinance.com - APP_ENV: credit-01
'''
    ),
    booleanParam(name: 'SKIP_DEPLOYMENT', defaultValue: false, description: 'Skip Application Deployment'),
    hidden(name: 'AWS_ACCOUNT', defaultValue: 'whizdmfinance-staging', description: 'AWS Account Name'),
    hidden(name: 'INFRA_ENV', defaultValue: 'stage', description: 'Infra Env'),
    hidden(name: 'GIT_REPO', defaultValue: 'https://bitbucket.org/whizdm/whizdm_customer.git', description: 'Repo URL'),
    hidden(name: 'MAIL', defaultValue: 'creditpod@moneyview.in', description: 'Email Id'),
    hidden(name: 'APP_NAME', defaultValue: 'whizdm_customer', description: 'Application Name'),
    hidden(name: 'PACKAGE_TYPE', defaultValue: 'jar', description: 'Build Package File Type WAR/JAR'),
    hidden(name: 'PACKAGE_NAME', defaultValue: 'scv-1.0', description: 'Build Package File Name'),
    hidden(name: 'BUILD_TARGET_PATH', defaultValue: 'scv-app/target', description:'Build WAR/JAR File Path'),
    hidden(name: 'SLACK_CHANNEL', defaultValue: 'jenkins-stg-build-deploy-alerts', description: 'Slack Channel Name'),
    hidden(name: 'DEVOPS_BUCKET_NAME', defaultValue: 'whizdmfinance-staging-cloud-platform', description: 'DevOps Bucket Name'),
    hidden(name: 'DEVOPS_BRANCH_NAME', defaultValue: 'master', description: 'DevOps Repo Branch Name'),
    hidden(name: 'DEVOPS_GIT_REPO', defaultValue: 'https://bitbucket.org/whizdm/devops.git', description: 'DevOps Repo'),
]

def NOW = LocalDateTime.now()
def TODAY_DATE = NOW.format(DateTimeFormatter.ofPattern("dd.MM.yyyy.HH.mm"))

properties([
    parameters(buildParameters)
])

def (APP_URL, APP_ENV) = "${params.DEPLOY_INFO}".tokenize("|")

def (AWS_ACCOUNT_ID, AWS_ACCOUNT_SHORT, AWS_REGION) = aws.getAwsAccountInfo(params.AWS_ACCOUNT).tokenize("|")
def INFRA_ENV_SHORT = environment.getCloudEnvironmentInfo(params.INFRA_ENV)

env.JOB_DETAIL = "Job: ${env.JOB_NAME} - App Env: ${APP_ENV} - Branch: ${params.BRANCH_NAME} - Build: ${env.BUILD_NUMBER}"
env.SLACK_MESSAGE = "${env.JOB_DETAIL}. \n More Info At: ${env.BUILD_URL}console"

if(params.BRANCH_NAME != ""){
    node("built-in"){
        timestamps{
            try{
                slackSend(color: "good", channel: "${params.SLACK_CHANNEL}", message: "*STARTED:* ${env.SLACK_MESSAGE}")
                
                stage("Set Build Details"){
                    wrap([$class : 'BuildUser']){
                         currentBuild.displayName = "#${env.BUILD_NUMBER} - ${APP_ENV} - ${params.BRANCH_NAME} By ${env.BUILD_USER}"
                    }
                }

                stage("Git Clone"){
                    dir("${params.APP_NAME}") {
                        git(branch: "${params.BRANCH_NAME}", credentialsId: 'bitbucket-cred', url: "${params.GIT_REPO}")
                        GIT_COMMIT_HASH = bbucket.getGitCommitHash()
                        GIT_COMMIT_HASH = "${GIT_COMMIT_HASH}".substring(0,7)
                        def commitId = sh(script: 'git rev-parse HEAD', returnStdout: true).trim()
                        shortCommitId = commitId.take(7)
                        shortCommitId = commitId.take(7)
                        echo "Full Commit ID: ${commitId}"
                        echo "Short Commit ID: ${shortCommitId}"
                        echo "${WORKSPACE}"
                    }
                }

                stage("Git Clone DevOps"){
                    dir("devops"){
                        git(branch: "${params.DEVOPS_BRANCH_NAME}", credentialsId: 'bitbucket-cred', url: "${params.DEVOPS_GIT_REPO}")
                    }                    
                }

                stage ("Build code and upload to s3") {
                    withEnv(["JAVA_HOME=/opt/java17", "PATH+EXTRA=/opt/java17/bin"]) {
                    dir ("${params.APP_NAME}") {
                        println "Current workspace: ${pwd()}"
                        sh """
                        cd /opt/${params.APP_NAME}/
                        mvn clean -q install -DskipTests
                        """
                        println "Current workspace: ${pwd()}"
                        sh "ls -ltr /opt/${params.APP_NAME}/build/libs"
                        println "${params.PACKAGE_TYPE} file upload to s3/Artifactory "
                        sh "aws s3 cp /opt/${params.APP_NAME}/build/libs/*.${params.PACKAGE_TYPE} s3://${params.BUCKET_NAME}/stage.apps.build.config/${params.APP_NAME}/builds/${params.APP_NAME}_${env.BUILD_NUMBER}_${shortCommitId}.${params.PACKAGE_TYPE} --no-progress"
                    }
                  }
                }

                stage("Build"){
                    ansiColor("xterm") {
                        dir("${params.APP_NAME}") {
                            sh """
                            cp ../devops/docker/apps/java-17.0.8_gradle-8.2.1_tomcat-10.1.12_deployment.Dockerfile ./
                            rm -rf src/main/resources/application.properties
                            aws s3 cp s3://${env.DEVOPS_BUCKET_NAME}/${params.INFRA_ENV}.apps.build.config/${APP_ENV}/${params.APP_NAME}/config/application.properties src/main/resources/application.properties --no-progress

                            aws ecr get-login-password --region ap-south-1 | docker login --username AWS --password-stdin ${AWS_ACCOUNT_ID}.dkr.ecr.ap-south-1.amazonaws.com
                            docker build -f java-17.0.8_gradle-8.2.1_tomcat-10.1.12_deployment.Dockerfile --build-arg AWS_ACCOUNT_ID=${AWS_ACCOUNT_ID} \
                            --build-arg APP_NAME=${params.APP_NAME} --build-arg PACKAGE_TYPE=${params.PACKAGE_TYPE} --build-arg BUILD_TARGET_PATH=${params.BUILD_TARGET_PATH} \
                            --build-arg BUILD_PATH=/opt/${params.APP_NAME} \
                            --build-arg WAR_FILE_NAME=${params.APP_NAME}_${env.BUILD_NUMBER}_${shortCommitId}.${params.PACKAGE_TYPE} \
                            -t ${AWS_ACCOUNT_ID}.dkr.ecr.ap-south-1.amazonaws.com/${params.APP_NAME}:${params.APP_NAME}-${params.INFRA_ENV} \
                            -t ${AWS_ACCOUNT_ID}.dkr.ecr.ap-south-1.amazonaws.com/${params.APP_NAME}:${GIT_COMMIT_HASH}.${TODAY_DATE}.${params.APP_NAME}-${params.INFRA_ENV} .

                            docker push ${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com/${params.APP_NAME}:${params.APP_NAME}-${APP_ENV}-${params.INFRA_ENV}
                            docker push ${AWS_ACCOUNT_ID}.dkr.ecr.ap-south-1.amazonaws.com/${params.APP_NAME}:${GIT_COMMIT_HASH}.${TODAY_DATE}.${params.APP_NAME}-${params.INFRA_ENV}
                            docker rmi  ${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com/${params.APP_NAME}:${params.APP_NAME}-${APP_ENV}-${params.INFRA_ENV} \
                            ${AWS_ACCOUNT_ID}.dkr.ecr.ap-south-1.amazonaws.com/${params.APP_NAME}:${GIT_COMMIT_HASH}.${TODAY_DATE}.${params.APP_NAME}-${params.INFRA_ENV} -f || true
                            docker system prune -f || true
                            """
                        }
                    }
                }

                if(!params.SKIP_DEPLOYMENT) {
                    stage("Deploy"){
                        ansiColor("xterm") {
                            dir("devops"){
                                sh """
                                aws ecs update-service --cluster ${INFRA_ENV_SHORT} --service ${INFRA_ENV_SHORT}-${APP_ENV}-scv --force-new-deployment --region ${AWS_REGION}
                                """
                            }
                        }
                    }
                }

                if(!params.SKIP_DEPLOYMENT) {
                    stage("Health Check"){
                        ansiColor("xterm") {
                            dir("devops"){
                                sh """
                                echo "Sleeping for min to verify Containers health."
                                sleep 2m
                                echo "After Deployment, Check Status of Old and New Containers."
                                """                                
                                aws.checkECS_ServiceTasksHealth("${INFRA_ENV_SHORT}", "${INFRA_ENV_SHORT}-${APP_ENV}-${params.APP_NAME}", "ap-south-1", 20, 10)
                            }
                        }
                    }
                }                

                slackSend(color: "good", channel: "${params.SLACK_CHANNEL}", message: "*SUCCESS:* ${env.SLACK_MESSAGE}")
                deleteDir()
            } catch(Exception ex){
                slackSend(color: "danger", channel: "${params.SLACK_CHANNEL}", message: "*FAILED:* ${env.SLACK_MESSAGE}")
                sh "docker system prune -f || true"
                deleteDir()
                throw ex
            }
        }
    }
} else {
    echo "Some Parameters are missing"
    slackSend(color: "warning", channel: "${params.SLACK_CHANNEL}", message: "*UNSTABLE:* ${env.SLACK_MESSAGE}")
    currentBuild.result = "Unstable"
    if (getContext(hudson.FilePath)) {
        deleteDir()
    }
}
