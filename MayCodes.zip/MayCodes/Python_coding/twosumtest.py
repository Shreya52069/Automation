def twosum(datalist, target):
    seen = {}
    for i in range(len(datalist)):
        diff = target - datalist[i]
        if diff in seen:
            return (seen[diff], i) #return indexes
        else:
            seen[datalist[i]] = i
print(twosum([2,5,7,3,8], 10))


