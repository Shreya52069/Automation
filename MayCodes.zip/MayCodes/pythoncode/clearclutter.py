import os
class Clutter:
    def __init__(self, ft, foldername):
        self.filetype =  ft
        self.foldername = foldername
    def fileName(self):
        files = []
        files = os.listdir(self.foldername)
        count = 1
        #print(files)
        for file in files:
            #print(file)
            if os.path.splitext(file)[1].lower() == self.filetype:
            #if file.endswith(self.filetype)
                #print(file.split(".")[0])
                #name = file.split(".")[0]
                newfile = self.foldername+str(count)+self.filetype
                os.rename(self.foldername+file, newfile)
                #os.path.splitext(file)[0] = str(count)
                #print(str(count))
                #print(os.path.splitext(file)[0])
                #print(type(os.path.splitext(file)[0]))
                #print(newfile)
                count = count+1
        renamedfiles = os.listdir(self.foldername)
        print(renamedfiles)
if __name__ == "__main__":
    foldername = "C:\\Users\\Shreya_Bhardwaj\\OneDrive - Dell Technologies\\Documents\\pythonprogramtestfolder\\"
    clutter1 = Clutter(".png", foldername)
    clutter1.fileName()