class Node:
    def __init__(self, value, left=None, right=None):
        self.value = value
        self.right = right
        self.left = left
    def __str__(self):
        return "Node("+str(self.value)+")"
def walk(tree, queue):
    queue.append(tree)
    while len(queue) >0:
        node = queue.pop(0)
        if node != None:
            print(node)
            queue.append(node.left)
            queue.append(node.right)
mytree = Node('A',Node('B', Node('D'), Node('E')), Node('C', Node('F'), Node('G')))
print(walk(mytree, []))
print(mytree)