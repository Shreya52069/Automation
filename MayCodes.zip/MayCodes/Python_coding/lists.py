thislist = ["apple", "banana", "cherry"]
if "banana" in thislist:
    print("yes, banana is there")

thislist.append("pineapple")
thislist.insert(1, "orange")
print(thislist)

#To append elements from another list to the current list, 
# use the extend() method.
thislist = ["apple", "banana", "cherry"]
tropical = ["mango", "pineapple", "papaya"]
thislist.extend(tropical)
print(thislist)
#We can also extend the list by tuple, dic or set

#remove method removes rhe forst occurrence
thislist = ["apple", "banana", "cherry"]
thislist.remove("banana")
print(thislist)

#to remove somthing from the index use pop()
thislist = ["apple", "banana", "cherry"]
thislist.pop(1)
print(thislist)

#del also removes from specified index
thislist = ["apple", "banana", "cherry"]
del thislist[0]
print(thislist)

#thislist.clear()
#loops for lists
li = [1,32,6,7,3,1,4,2,2]
for num in li:
    print(num)
for i in range(len(li)):
    print(li[i])

thislist = ["apple", "banana", "cherry"]
i = 0
while i < len(thislist):
  print(thislist[i])
  i = i + 1

#list comprehension
thislist = ["apple", "banana", "cherry"]
[print(x) for x in thislist]

fruits = ["apple", "banana", "cherry", "kiwi", "mango"]
newlist = []
for x in fruits:
    if "a" in x:
        newlist.append(x)

newlist = [x for x in fruits if "a" in x]

#syntax for list comprehension
#newlist = [/expression/ for item in iterable if condition == True]
newlist = [x if x != "banana" else "orange" for x in fruits]

#sort list alpha numerically- 
thislist = ["orange", "mango", "kiwi", "pineapple", "banana"]
thislist.sort()
print(thislist)

#sort in descending order- 
thislist = ["orange", "mango", "kiwi", "pineapple", "banana"]
thislist.sort(reverse = True)
print(thislist)

#customize sort func
def myfunc(n):
  return abs(n - 50)
#abs returns absolute value

thislist = [100, 50, 65, 82, 23]
thislist.sort(key = myfunc)
print(thislist)

# this is basically applying the func on every element and then sorting
#Note- sort() fucntion is case sensitive- sorts capital letters before small
thislist = ["banana", "Orange", "Kiwi", "cherry"]
thislist.sort()
print(thislist)
thislist = ["banana", "Orange", "Kiwi", "cherry"]
thislist.sort(key = str.lower)
print(thislist)

#reverse()

#copy a list
thislist = ["apple", "banana", "cherry"]
mylist = thislist.copy()
print(mylist)

#join lists- or use extend(s)
list1 = ["a", "b", "c"]
list2 = [1, 2, 3]

list3 = list1 + list2
print(list3)