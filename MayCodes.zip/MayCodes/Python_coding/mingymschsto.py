blocks = [
    {'gym': False, 'school': True, 'store': False},  # Block 0
    {'gym': True, 'school': False, 'store': False},  # Block 1
    {'gym': True, 'school': True, 'store': False},   # Block 2
    {'gym': False, 'school': True, 'store': False},  # Block 3
    {'gym': False, 'school': False, 'store': True},  # Block 4
]
def mindistance(blocks):
    numblocks = len(blocks)
    if numblocks == 0:
        return -1
    distances = {'gym': [float('inf')]*numblocks,
                'school': [float('inf')]*numblocks,
                'store': [float('inf')]*numblocks}
    #move from left to right and right to left to put the minimum distance
    for req in distances:
        last_seen = float('inf')
        for i in range(numblocks):
            if blocks[i][req]:
                last_seen = i
            if last_seen != float('inf'):
                distances[req][i] = abs(i-last_seen)
        last_seen = float('inf')
        for i in range(numblocks-1, -1, -1):
            if blocks[i][req]:
                last_seen = i
            if last_seen != float('inf'):
                distances[req][i] = min(distances[req][i], abs(i-last_seen))
        max_min_distance = float('inf')
        max_min_index = 0
        for i in range(numblocks):
            maxdis = max(distances[req][i] for req in distances)
            if maxdis < max_min_distance:
                max_min_distance = maxdis
                max_min_index = i
    return max_min_index

print(mindistance(blocks))


