s = "python"
def unique(s):
    d =[]
    for char in s:
        if char not in d:
            d.append(char)
            print(d)
        elif char in d:
            print("not unique")
            break
unique(s)
x = "Hello"
unique(x)

def rotation(s1,s2):
    d = []
    e = []
    for char in s1:
        d.append(char)
    for c in s2:
        e.append(c)
    print(d)
    print(e)
    print(sorted(d) == sorted(e))
    #for i in range(len(s1)):
        #if d[i] == e[i]:
         #   print("same")
        #elif d[i] == e[i-1]:
        #    print("d")
rotation("ABCD", "DABC")