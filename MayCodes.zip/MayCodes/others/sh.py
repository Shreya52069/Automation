import string
import threading
import time
import requests

def cleantext(text):
    return ''.join([char for char in text if char not in string.punctuation])
line = "Hi, My name is Shreya! I hope you are having a good day"
ctext = cleantext(line)
print(ctext)
d = {}
for w in line.split():
    word = w.lower()
    if word in d:
        d[word] = d[word] + 1
    else:
        d[word] = 1
#d[word] = d.get(word, 0) +1
print(d)

def one():
    print("hi")
    time.sleep(10)
def two():
    print("bye")
    time.sleep(20)
thread1 = threading.Thread(target=one)
thread2 = threading.Thread(target=two)

thread1.start()
thread2.start()
thread1.join()
thread2.join()
