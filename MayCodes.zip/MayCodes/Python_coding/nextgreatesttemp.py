def dailyTemperatures(temperatures):
    temlen = len(temperatures)
    stack = []
    result = [-1]*temlen
    for i in range(temlen):
        while stack and temperatures[i] > temperatures[stack[-1]]:
            index = stack.pop()
            result[index] = i-index
        stack.append(i)
    return result
print(dailyTemperatures([73,74,75,71,69,72,76,73]))

