def ispalindrome(s):
    l = 0
    r = len(s)-1
    while l < r:
        if s[r] == s[l]:
            l += 1
            r -= 1
        if s[r] != s[l]:
            return False
    return True

print(ispalindrome('ababababa'))
def longestpalind(s):
    res = ''
    reslen = 0
    for i in range(len(s)):
        l,r = i, i
        while l >=0 and r < len(s) and s[l] == s[r]:
            if r-l+1 > reslen:
                res = s[l:r+1]
                reslen = len(res)
            l -= 1
            r += 1
        l, r= i, i+1
        while l >=0 and r < len(s) and s[l] == s[r]:
            if r-l+1 > reslen:
                res = s[l:r+1]
                reslen = len(res)
            l -= 1
            r += 1
    return reslen
print(longestpalind('ababacdcda'))

def is_palindrome(s: str) -> bool:
    return s == s[::-1]

def reverseplaindrome(s):
    return s[::-1]

