Product management questions:
1. Why is having consistent releases better?
- I understand the part that it give sus the ability to ass more features
But - customers have to update regularly or what if we have dependencies?
IS the release cycle not product based?

**Changing how you build
 Changing how you solve problems means moving from stakeholder-driven roadmaps and feature teams, to empowered product teams given problems to solve, and then using product discovery to come up with solutions that are valuable, usable, feasible and viable.
3. Product vision: head of product
These are the factors that I consider essential as we craft the product vision:

Business Objectives and Constraints
Customer Problems
Critical Insights
Enabling Technologies
Industry Trends
Competitive Landscape
Go To Market Considerations
Our Own Capabilities
Organizational Impacts

While the product strategy changes frequently (at least yearly if not quarterly, based on new data and insights), the product vision doesn’t usually change much at all. 
Sometimes during our product strategy or product discovery work we uncover an insight that is so impactful that we decide it makes sense to change the direction of the company.  That is called a vision pivot.

Core principals for strong product teams:
1. PROTECTING CUSTOMERS, REVENUE, BRAND, 
2. RESPONDING TO MARKET NEEDS
3. EARNING THE TRUST OF OUR CUSTOMERS
4. SMALL, FREQUENT, RELIABLE RELEASES: 
    regression and automation testing are very imp here.
    New feature should work as expected and it should not unintentionally break anything- backward compatible.- this is regression testing.
    The main method product teams use to ensure that new capabilities work as advertised, and don’t introduce regressions, is to deploy a series of very frequent, very small changes. 
    The smaller the release increment, the faster we can ensure the quality of the new capability, and the faster we can be confident we’re not introducing regressions.  And with these small, frequent releases, if a problem is introduced, it is much easier and faster to identify the cause (since we only changed a small number of things).
    Moreover, even if the new release actually works as it’s supposed to (a very big if), the customer is forced to absorb hundreds or even thousands of product changes hitting them all at once, likely requiring retraining, recertification, reintegration, and otherwise significantly interrupting their own work to accommodate all the changes the company has forced upon them.  
    In this case, it’s all too common for the customer to press your company to release less frequently, because they simply have no time to deal with this degree of change.  As you can hopefully see by now, while it is completely understandable why the customer would request this, doing so would be much worse for the customer, and worse for your company.

    **How to solve problems:
    Dont go down the road which si feature based solutions.
    The root of the issue is that these feature teams are set up to serve the stakeholders in your business, rather than to serve your customers in ways that work for your business.
    The stakeholders or feature team blames developers that the feature came out differently and dev blames feature team as to we just built what was asked
    Another serious consequence of this way of working is that we end up with a great many “orphaned” features – features that don’t produce real value, but are waiting for the day they might get another iteration, which rarely happens.  The result is very fast accumulation of technical debt, which can quickly get out of hand and end up dramatically slowing down the feature teams, or in some cases bringing the business to its knees.
    
    SOLVING PROBLEMS FOR OUR CUSTOMERS AND OUR BUSINESS:
    In this case, rather than providing the product team with a roadmap of features and projects to build, the product team is instead given a set of problems to solve and desired outcomes to achieve.

    But in an empowered product team, the engineers are not just there to build, they are also responsible for helping to identify the right solution.  This is what is meant by the term empowered engineer.

    When combined with a strong product designer trained in the craft of designing effective and engaging user experiences, and a capable product manager trained in understanding both customers and the constraints of your business, you have the cross-functional set of skills necessary to solve hard problems in ways our customers love, yet work for our business.
    With this as the goal of the product team, the incentive moves to being able to quickly determine if a particular product idea or approach will work.  This is referred to as "product discovery"

    Product discovery: Building prototypes -which are fast and inexpensive to create. 
    Strong, cross-functional, empowered product teams of product managers, product designers and engineers working together to solve customer problems in ways that our customers love, yet work for our business, is the essential core competency of a product-led company.

    **What problems to solve?
    1. CUSTOMER-DRIVEN PRODUCT VISION
        So many companies spend their time reacting – reacting to new sales opportunities, reacting to competitor’s offerings, reacting to customer requests, and reacting to price pressure.  Yet in strong product companies, while they care about these factors, they are not driven by them.

        What drives them is the pursuit of a product vision that can meaningfully improve the lives of their customers.
        In fact, in a strong product company, a compelling and inspiring product vision is our single best tool for inspiring our product teams.  The people you want on your teams are precisely those that believe in your product vision.  They want to make a difference in the lives of your customers.
    2. Strong product strategy: dont try to do it all in one go. Focus on features which will brring value to your product and to your customers. 

    USER Stories- Complete in 1 sprint
    Epics- 
    Google analytics tool: free- easy to use.
    CBA- cost benefit analysis