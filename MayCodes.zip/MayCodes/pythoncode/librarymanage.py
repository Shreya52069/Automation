class Library:
    def __init__(self, no_of_books, books):
        self.n = no_of_books
        self.b  = books

    def allbooks(self):
        print( f"Number of books in Library are: {len(self.b)}")
        print("all books are:\n")
        for book in self.b:
            print(book)

    def addbook(self, book):
        self.b.append(book)
        print("New list of books")
        for book in self.b:
            print(book)
        print(f"Now number of books are: {len(self.b)}")
        self.n = len(self.b)

l = Library(4, ["ikigia", "think like a monk", "hippie", "gita"])
l.allbooks()
l.addbook("Trainspotting")

