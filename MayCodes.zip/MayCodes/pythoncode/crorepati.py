questions = [
    ["Which lang was used to create facebook?",
"Python", "French", "Javascript", "php", "None", 4], 
["Which lang was used to create insta?",
"Python", "Java", "Javascript", "php", "None", 2],
["Which lang was used to create youtube?",
"Python", "Go", "Javascript", "php", "None", 2],
["Which lang was used to create google?",
"Python", "French", "Javascript", "php", "None", 1],
["Which lang was used to create ios?",
"Python", "C++", "Objective C", "php", "None", 3],
["Which lang was used to create Windows?",
"Python", "C", "Javascript", "php", "None", 2],
["Which lang was used to create uber ?",
"Python", "French", "Javascript", "php", "None", 1],
["Which lang was used to create Amazon?",
"Python", "Java", "Javascript", "php", "None", 2],
["Which lang was used to create Reddit?",
"Python", "Lisp", "Javascript", "php", "None", 12],
["Which lang was used to create chatgpt?",
"Python", "French", "Javascript", "php", "None", 1] 
]

levels = [1000, 2000, 3000, 5000, 10000, 20000, 40000, 80000, 160000,320000]
money = 0
for i in range(0, len(questions)):
    question = questions[i]
    print(f"Question for Rs. {levels[i]}")
    print(question[0])
    print(f"a. {question[1]}       b. {question[2]}")
    print(f"a. {question[3]}       b. {question[4]}")
    reply = int(input("Enter your answer(1-4)"))
    if reply == question[-1]:
        print(f"Corret answer: you win {levels[i]} rupees")
        if(i == 4):
            money = levels[i]
        elif(i == 8):
            money = levels[8]
    else:
        print("Incorrect answer")
        if(i < 4):
            money = 0
            print("Sorry, no money")
        else:
          print(f"Sorry the game ends here, but you won {money} rupees")
        break
