import string
li = [2,3,5,6,4,1,1,6,8,4]
d = {}
co = {}
for num in li:
    print(num)
    if num not in d:
        d[num] = 1
    else:
        d[num] = d[num] +1
for num in li:
    co[num] = co.get(num,0)+1
print(d)
print(co)

sen = "Hello, I'm practicing again. I am sorry that I was not doing this since some time. I need to pick up some speed."
cleansen = ''
for char in sen:
    print(char)
    if char in string.punctuation:
        print("this is punctuatiuon")
    else:
        cleansen += char
print(cleansen)
news = ''.join([char for char in sen if char not in string.punctuation])
print(news)
sendict = {}
for word in cleansen.split():
    if word in sendict:
        sendict[word] = sendict[word] + 1
    else:
        sendict[word] = 1
print(sendict)

def prime(x):
    if x == 0:
        st = "It is 0"
        return st
    if x == 1:
        return 1
    else:
        for n in range(2,x):
            if x % n == 0:
                print("not a prime number")
                break
def fact(n):
    if n == 0:
        return 0
    if n == 1:
        return 1
    else:
        return n * fact[n-1] 

def fibo(n):
    z = []
    if n == 0:
        return 0
    if n == 1:
        return [0,1]
    else:
        for i in range(n):
            if i == 0:
                z.append(0)
            elif i == 1:
                z.append(1)
            else:
                z.append(z[i-1] + z[i-2])
        return z
print(fibo(10))
double = lambda x: x*2
def lam(fx, val):
    jj = fx(val)
    return jj
print(lam(double,4))

def filterfun(n):
    return n > 4
lis = [1,24,5,67,4,1,4,3,2,1]
newlis = filter(filterfun, lis)
print(newlis)

def fn(n):
    return n*n*n
neo = list(map(fn, lis))
print(neo)