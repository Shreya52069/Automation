def find_min_distance_block(blocks):
    num_blocks = len(blocks)
    if num_blocks == 0:
        return -1

    # Initialize distances for each requirement
    distances = {'gym': [float('inf')] * num_blocks, 'school': [float('inf')] * num_blocks, 'store': [float('inf')] * num_blocks}
    
    # Calculate the minimum distance to each requirement (gym, school, store) for each block
    for req in distances:
        last_seen = float('inf')
        
        # Left to right pass
        for i in range(num_blocks):
            if blocks[i][req]:
                last_seen = i
            if last_seen != float('inf'):
                distances[req][i] = abs(i - last_seen)
        
        last_seen = float('inf')
        # Right to left pass
        for i in range(num_blocks - 1, -1, -1):
            if blocks[i][req]:
                last_seen = i
            if last_seen != float('inf'):
                distances[req][i] = min(distances[req][i], abs(i - last_seen))

    # Find the block with the minimum total distance to gym, school, and store
    min_total_distance = float('inf')
    min_block_index = -1

    for i in range(num_blocks):
        total_distance = sum(distances[req][i] for req in distances)
        if total_distance < min_total_distance:
            min_total_distance = total_distance
            min_block_index = i
    
    return min_block_index

# Example usage
blocks = [
    {'gym': False, 'school': True, 'store': False},
    {'gym': True, 'school': False, 'store': False},
    {'gym': True, 'school': True, 'store': False},
    {'gym': False, 'school': True, 'store': False},
    {'gym': False, 'school': True, 'store': False},
    {'gym': False, 'school': False, 'store': True}
]

min_block_index = find_min_distance_block(blocks)
print(f"The block with the minimum total distance to gym, school, and store is block {min_block_index}.")
