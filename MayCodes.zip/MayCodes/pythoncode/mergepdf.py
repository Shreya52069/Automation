import pypdf
from pypdf import PdfFileWriter
import os
merger = PdfFileWriter()

files = [file for file in os.listdir() if file.endswith(".pdf")]

for pdf in files:
    merger.append(pdf)

merger.write("merged-pdf.pdf")
merger.close()
