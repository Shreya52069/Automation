import threading
import time
import string

def fucn1():
    print("Fucntion 1")
    time.sleep(2)
    print("End of func1")
def func2():
    print("Start of func2")
    time.sleep(3)
    print("end of fucn2")
j = threading.Thread(target=fucn1)
k = threading.Thread(target= func2)
j.start()
k.start()

j.join()
k.join()

print("end treading")

line = "Hello. Vitamins and minerals are very important. Important are vitamins and minerals."
list1 = line.split()
dict1={}
for w in list1:
    #dict1[word] = dict1.get(word,0)+1
    sm = w.lower()
    word = sm.strip(string.punctuation)
    if word not in dict1:
        dict1[word] = 1
    else:
        dict1[word] = dict1[word] + 1
print(dict1)

x = int(input("Enter a number:"))
if x%2 == 0:
    while True:
        if x != 0:
            x = x/2
            if x == 1:
                print("x is power of 2")
                break
            elif x != 1 and x%2 != 1:
                print("not a power of 2")
                break
            
elif x % 2  != 0:
    print("not a power of 2")

subsrt="the"
str1 = "Pathanoic acid is vitamin b5"
if str1.__contains__(subsrt):
    print("present")
