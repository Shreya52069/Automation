import string
import time
import threading
import multiprocessing

line = "Hello, hello. this line has repeated words. Repeated words are in this line."

def cleantext(text):
    return ''.join([char for char in text if char not in string.punctuation])

x = cleantext(line)
print(x)
d = {}
for word in x.split():
    w = word.lower()
    if w in d:
        d[w] = d[w] + 1
    else:
        d[w] = 1
print(d)

def one():
    print("this is one")
    time.sleep(10)
    print("hi")
def two():
    print("This is two")
    time.sleep(10)
    print("hello")
thread1 = threading.Thread(target=one)
thread2 =  threading.Thread(target=two)
thread1.start()
thread2.start()
thread1.join()
thread2.join()

#stemmedlist = ["ing", "ed", "ly"]
newl = "fox in jumping, kid is running and kite is flying and I stepped on the floor. It was lovely"
statement = []
cleannewl = cleantext(newl)
for word in cleannewl.split():
    if word.endswith("ing"):
        word = word[:-3]
    elif word.endswith("ed") or word.endswith("ly"):
        word = word[:-2]
    statement.append(word)
ll = ' '.join(statement)  
print(ll)

def fibo(n):
    z = []
    if n == 0:
        return 0
    if n == 1:
        return [0,1]
    else:
        for i in range(n):
            if i == 0:
                z.append(0)
            if i == 1:
                z.append(1)
            else:
                z.append(z[i-1] + z[i-2])
        return z
def fact(n):
    if n == 0:
        return 0
    if n == 1:
        return 1
    else:
        x = n * fact(n-1)
        return n

largest = [1,5,4,2,6,8,3,10,45,65,76,92,14,144]
large = 0
for i in largest:
    if i > large:
        large = i
print(large)
small = None
for j in largest:
    if small == None:
        small = j
    elif small != None and j < small:
        small = j
print(small)
def prime(n):
    for i in range(2, n-1):
        if n % i == 0:
            print("n is not prime")
            y = 1   
            break
    if y == 1:
        print("It is not a prime number")
    else:
        print("It is prime")

double = lambda x: x*2
print(double(2))    
li = list(map(double, [2,5,7,8,4,6]))
print(li)

        


