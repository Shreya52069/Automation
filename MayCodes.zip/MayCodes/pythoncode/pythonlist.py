def fiboo(x):
    z= []
    if(x == 0):
        return 0
    elif x == 1:
        return 1
    else:
        for i in range(x):
            if i == 0:
                z.append(0)
            elif i == 1:
                z.append(1)
            else:
                z.append(z[i-1]+z[i-2])
    print(z)
    return z
fiboo(20)