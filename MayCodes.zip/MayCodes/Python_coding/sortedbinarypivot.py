def sortedpivotbinary(arr, target):
    l = 0
    r = len(arr)-1
    while l < r:
        mid = (l+r)//2
        if arr[mid] == target:
            return mid
        #left sorted
        if arr[l] < arr[mid]:
            if target >= arr[l] and target < arr[mid]:
                r = mid -1
            else:
                l = mid+1
        else:
            if target > arr[mid] and target < arr[r]: 
                l = mid +1
            else:
                r = mid -1
    return False
print(sortedpivotbinary([4,5,6,7,0,1,2], 1))
