from typing import List
class Solution:
    def twoSum(self, nums: List[int], target: int) -> List[int]:
        seen = {}
        for i in range(len(nums)):
            diff = target -  nums[i]
            if diff in seen:
                return [seen[diff], i]
            else:
                seen[nums[i]] = i

obj = Solution()
val = obj.twoSum([2,7,11,15], 9)
print(val)

# only 1 number will be there for each num in array to be equal to target
#learning- to not revisit or reiterate the list again and again- we save each value to the dict 
#and check the dict if we have already iterated that value

