declare -i SUM=5
declare -i FINAL=20
while true
do   
    SUM=$(($SUM+5))
    echo $SUM
    if [ $SUM -eq $FINAL ]
    then
        break
    fi
done

read -p "What is your name" NAME
echo "my name is ${NAME}"
for USER in "$@";
do
    echo "Hi ${USER}"
done
if [ "$NAME" = "shreya" ]
then
    echo "lalala"
fi