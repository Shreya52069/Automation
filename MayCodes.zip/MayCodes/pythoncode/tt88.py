def remove_leading_zeros(input_str):
    input_string = input_str.split(':')
    index = 0
    for i in range(len(input_string)):
        print(input_string[i])
        while index < len(input_string[i]) and input_string[i][index] == '0':
            index += 1
            input_string[i] = input_string[i][index:]
        print(i)
    return (':').join(input_string)

test_string = "2607:f2b1:5609:0004:1::5"
result = remove_leading_zeros(test_string)
print(result) 