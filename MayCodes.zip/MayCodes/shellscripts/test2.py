z = int(input("Enter the number: "))
while True:
    if z % 2 == 0:
        if z != 0:
            z = z/2
            if z == 1:
                print("Number passed is a power of 2")
                break
        else:
            print("not a power of 2")
            break
    elif z % 2 != 0:
        print("not a power of 2")
        break
