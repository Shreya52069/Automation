#!/bin/bash -e -x
DEBUG=true
debud(){
    echo "Executing $@"
    $DEBUG && $1
    DEBUG=false
    $DEBUG && $2
    DEBUG=true
    $DEBUG && $3
}
debug ls ls ls