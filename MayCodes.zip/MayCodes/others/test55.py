double = lambda x:x*2
for i in range(5):
    print(double(i))
def newstring(ip, port):
    listofzeros = ["0","00","000"]
    if ip.__contains__(":"):
        iplist = ip.split(":")
        for i in iplist:
            #print(i)
            if i.startswith("0"):
                print(i.lstrip("0"))
obj1 = newstring("2607:f2b1:5609:0004:1::5", 8023)
print(obj1)
