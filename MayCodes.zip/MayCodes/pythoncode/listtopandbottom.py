list1 = [1,2,3,4,5,6,7,8,9,10]
x = int(input("input the num: "))
i = 0
#for i in range(0, len(list1)):
#while len(list1) != 4:
    #print(i)
for i in range(x):
    list1.pop(i)
for j in range(x):

    print(list1)
    #list1.pop(i)
    #print(list1)
    #list1.pop(-1)
    #print(list1)
    #list1.pop(-1)
    #print(list1)
print(list1)
list1.pop(0)
print(f"Last person to be selected{list1}")

from collections import deque

# Function to pop x items from front and x items from back
def pop_items(queue, x):
    # Pop x items from front of the queue
    for _ in range(x):
        queue.popleft()
    
    # Pop x items from back of the queue
    for _ in range(x):
        queue.pop()

# Main function
def main():
    # Create a deque (double-ended queue)
    queue = deque([1, 2, 3, 4, 5])

    # Ask the user for the number of items to pop from front and back
    x = int(input("Enter the number of items to pop from front and back: "))

    # Pop x items from front and back
    pop_items(queue, x)

    # Print the last item remaining in the queue
    print("Last item remaining:", queue[-1])

# Run the main function
if __name__ == "__main__":
    main()
