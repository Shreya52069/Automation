Systems scaled up- possible issues:
network latency
throuput
part failures- if using hardware
unresponse applications
monitoring and logging- prometheus
python logging library


api gateway- number of req max
access logs- kaha se req aayi- 
error logs- infra error- scaling- 
application level error- actual code error

req error from client
infra level issue- application 

distributed systems- used to storage- master-slave (mysql cluster, prostgres cluster)- partitioning, replicaton, sharding

data streaming- youtube or twitter- 
peer to peer(all servers are independent)- kafka-- aate hue data ko todhi der ke liye store kia and uspe analysis done by consumer- 
distributed queue(partitioning and replication)- retain data for sometime- streaming data 

producer----- kafka----consumer

databases architecture -


network security- address as well as in transit encrypt


grpc and rest
ports in network


application is distributed--- 2 salves should be able to communication eachother overnetwork using rpc