def myAtoi(self, s: str) -> int:
    res = 0
    i = 0
    sign = 1
    n = len(s)
    
    # Skip leading whitespaces
    while i < n and s[i] == ' ':
        i += 1
    
    # Check if the string is empty after removing whitespaces
    if i >= n:
        return 0
    
    # Check for sign
    if s[i] == '-':
        sign = -1
        i += 1
    elif s[i] == '+':
        i += 1
    
    # Process digits
    while i < n and s[i].isdigit():
        res = res * 10 + int(s[i])
        i += 1
        
        # Handle overflow/underflow
        if res * sign > 2**31 - 1:
            return 2**31 - 1
        if res * sign < -2**31:
            return -2**31
    
    return res * sign
