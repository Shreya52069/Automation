import string
x = string.punctuation
print(x)
def commas():
    str1 = "Hello Shreya, you are the best, you can do better shreya. The best you can do is be better."
    list1 = str1.lower().split()
    dic1 = {}
    for word in list1:
        #w = word.casefold()
        #if string.punctuation in w:
         #   w = 
        dic1[word] = dic1.get(word,0)+1
    print(dic1)
commas()

def remove_punctuation(text):
    return ''.join([char for char in text if char not in string.punctuation])

# Example usage:
text = "Hello, world! This is a sample text, with punctuations."
clean_text = remove_punctuation(text)
print(clean_text)
line = ''
for char in text:
     if char not in string.punctuation:
        line += char
        print(char)
print(line)

#slicing
teststr = "Hello mr dj"
print(teststr[:5])
#lstrip rstrip
teststr.find("mr")
teststr.replace("ello", "llo")
teststr.startswith("H")