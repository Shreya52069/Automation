s = "Go to networking and perform actions. go to network"
t = s.split()
print(t)
k = ' '.join(t)
print(k)
sub = "net"
if s.__contains__(sub):
    print("yes")
d = {}
for word in s.split():
    w = word.lower().rstrip()
    if w in d:
        d[w] = d[w]+1
    else:
        d[w] = 1
print(d) 
i = (x for x in range(4) if x%2 == 0)
print(i)
i = (x for x in range(4) if x % 2 == 0)

# Using a for loop to iterate over the generator object
for num in i:
    print(num)

# Or, you can convert the generator object to a list
i_list = list(i)
print(i_list)