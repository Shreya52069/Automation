for i in range(5, 40, 2):
        print(i)
print("hrllp"[:2])
def files():
    testfile = open('C:\Shreya_personal\Python\MayCodes\pythoncode\password_generator.py', 'r')
    count = 0
    for line in testfile:
        print(line)
        count = count + 1
    print(count)
    print(testfile.readlines())
    h = testfile.readlines()
    print(h)
    with open('C:\Shreya_personal\Python\MayCodes\pythoncode\password_generator.py', 'r') as kk:
        print(kk.readlines())
files()
x = [2,5,6,7,8,9,10,22,27,29,29]
ff = ["h", "g", "d", "t", "y"]
for i in range(len(x)):
    print(f"{i} position: {x[i]}")
for i in range(len(x)):
    print(f"{i} position: {x[i]}")
for j in ff:
    print(j)
for y in x:
    print(y)
#print(x)
y = x.sort()
print(y)
print(max(x))
def ref(mylist,q):
    print(mylist)
    q = 2 # this is local variable- gets destroyed
    print(q)
    mylist[2] = 40
    print(mylist)
    return
mylist = [10,20,70,50]
q = 10
ref(mylist,q)
print(mylist)
print(q)