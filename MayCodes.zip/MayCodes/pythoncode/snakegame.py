class SnakeWaterGun:
    def __init__(self, firstplayer, secondplayer):
        self.f = firstplayer
        self.s = secondplayer
    def twoPlayers(self):
       # if(self.f == "gun" and self.s == "snake"):
       #     print("firstplayer wins")
       # elif(self.f == "gun" and self.s == "water"):
       #     print("second player wins")
        if(self.f == "gun"):
            if(self.s == "snake"):
                print("firstplayer wins")
            elif(self.s == "water"):
                print("second player wins")
            elif(self.s == "gun"):
                print("draw")
            else:
                print("wrong input")
        if(self.f == "snake"):
            if(self.s == "snake"):
                print("draw")
            elif(self.s == "water"):
                print(" first player wins")
            elif(self.s == "gun"):
                print("second player wins")
            else:
                print("wrong input")
        if(self.f == "water"):
            if(self.s == "snake"):
                print("second player wins")
            elif(self.s == "water"):
                print("draw")
            elif(self.s == "gun"):
                print("first player wins")
            else:
                print("wrong input")

roundone = SnakeWaterGun("gun", "water")
roundone.twoPlayers()

import random
print(random.randint(0,2))
#def check(comp, user):