#linked list has 2 vals- data and index of the next node.
#val,idx--->val,idx---> val,idx

#when inserting another val then: val,newidx--->val,idxofnextwhich was with previous val--->val,sameidx---> val,sameidx

#benefits- we dont have to allocate memory beforehand. insertion, deletion at start or end is O(1) complexity
#everywbere else is O(n) cuz we have to traverse the ll

#double linked list-
# none,val,idx--->previdx,val,idx---> precidx,val,idx   

#indexing-array O(1), ll- O(n)
#insert,delete at start- O(n), ll O(1)
#insert,delete at end- O(1), O(n)
#insert in middle- O(n), O(n)

#we access all data uisng head- head is a third thing which is used to point to data
#Node class is used with __init__ method to initialize it.
#Next, we have created an insertAtBegin() method to insert a node at the beginning of the linked list, 
#an insertAtIndex() method to insert a node at the given index of the linked list, and insertAtEnd() 
# method inserts a node at the end of the linked list. After that, we have the remove_node() method which 
# takes the data as an argument to delete that node. In the remove_node() method we traverse the linked list 
#if a node is present equal to data then we delete that node from the linked list. Then we have the sizeOfLL() 
# method to get the current size of the linked list and the last method of the LinkedList class is printLL() which 
# traverses the linked list and prints the data of each node.

#--------------------
# Create a Node class to create a node- represents individual element in a linkedlist
class Node:
    def __init__(self, data, next=None):
        self.data = data
        self.next = next #pointer to next element
 
# Create a LinkedList class˜
 
class LinkedList:
    def __init__(self):
        self.head = None 
 
    # Method to add a node at begin of LL
    def insertAtBegin(self, data):
        new_node = Node(data, self.head) # we are inserting something infront of head- so the pointer will now pointer to previous head
        self.head = new_node
    def print(self):
        if self.head is None:
            print("empty ll")
            return
        itr = self.head
        llstr = ''
        while itr: #here we are iterating through ll
            llstr += str(itr.data)+ '---->' #note-0 itr has itr.data and itr.next- that means - self.head has data and next both in it
            itr = itr.next
        print(llstr)
    
    def insertatend(self, data):
        if self.head is None: #when your ll is empty
            self.head = Node(data, None)
            return
        #now lets say your ll is not empty- you need to iterate over the ll and go to the end. 
        itr = self.head
        while itr.next:
            itr = itr.next
        
        itr.next = Node(data, None) # as this element is null- point it to new node
               
    #creating fresh ll with list of values
    def insert_vals(self, data_list):
        self.head = None
        for data in data_list:
            print(data)
            self.insertatend(data)

    #print len of ll
    def sizeofll(self):
        count = 0
        itr = self.head
        while itr:
            count += 1
            itr = itr.next
        return count
    
    # remove element from an index

    def remove_at(self, index):
         if index<0 or index>=self.sizeOfll():
             raise Exception("invalid")
         if index == 0:
             self.head = self.head.next
             return
         count = 0
         itr = self.head
         while itr:
              if count == index-1:
                  itr.next = itr.next.next
                  break
              itr = itr.next
              count += 1
            
                 
    # Method to add a node at any index
    # Indexing starts from 0.
    def insertat(self, index, data):
        if index<0 or index>=self.sizeofll():
            raise Exception("invalidindex")
        if index == 0:
            self.insertAtBegin(data)
            return
        count = 0
        itr = self.head
        while itr:
            if count == index-1:
                newnode = Node(data, itr.next)
                itr.next = newnode
                break
            itr = itr.next
            count += 1
 
    # Update node of a linked list
        # at given position
    def updateNode(self, val, index):
        current_node = self.head
        position = 0
        if position == index:
            current_node.data = val
        else:
            while(current_node != None and position != index):
                position = position+1
                current_node = current_node.next
 
            if current_node != None:
                current_node.data = val
            else:
                print("Index not present")
 
    # Method to remove first node of linked list
 
    def remove_first_node(self):
        if(self.head == None):
            return
 
        self.head = self.head.next
 
    # Method to remove last node of linked list
    def remove_last_node(self):
 
        if self.head is None:
            return
 
        current_node = self.head
        while(current_node.next.next):
            current_node = current_node.next
 
        current_node.next = None
 
    # Method to remove at given index
    def remove_at_index(self, index):
        if self.head == None:
            return
 
        current_node = self.head
        position = 0
        if position == index:
            self.remove_first_node()
        else:
            while(current_node != None and position+1 != index):
                position = position+1
                current_node = current_node.next
 
                if current_node != None:
                    current_node.next = current_node.next.next
                else:
                    print("Index not present")
 
    # Method to remove a node from linked list
    def remove_node(self, data):
        current_node = self.head
 
        if current_node.data == data:
            self.remove_first_node()
            return
 
        while(current_node != None and current_node.next.data != data):
            current_node = current_node.next
 
        if current_node == None:
            return
        else:
            current_node.next = current_node.next.next
 
    # Print the size of linked list
    def sizeOfLL(self):
        size = 0
        if(self.head):
            current_node = self.head
            while(current_node):
                size = size+1
                current_node = current_node.next
            return size
        else:
            return 0
 
 
# create a new linked list
llist = LinkedList()
 
# add nodes to the linked list
#llist.insertAtEnd('a')
#llist.insertAtEnd('b')
#llist.insertAtBegin('c')
#llist.insertatend('d')
#llist.insertAtIndex('g', 2)
llist.insert_vals(["a","e","i"])
llist.print() 
# print the linked list
#print("Node Data")
#llist.printLL()
 
# remove a nodes from the linked list
#print("\nRemove First Node")
#llist.remove_first_node()
#print("Remove Last Node")
#llist.remove_last_node()
#print("Remove Node at Index 1")
#llist.remove_at_index(1)
 
 
# print the linked list again
#print("\nLinked list after removing a node:")
#llist.printLL()
 
#print("\nUpdate node Value")
#llist.updateNode('z', 0)
#llist.printLL()
 
#print("\nSize of linked list :", end=" ")
#print(llist.sizeOfLL())