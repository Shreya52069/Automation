from prometheus_client import start_http_server #So from prometheus client, first I've imported the same start http server library to start an HTTP server to serve the Prometheus metrics.
from prometheus_client.core import REGISTRY, CounterMetricFamily, GaugeMetricFamily #registry I've imported
#to help us to add a collector to the registry.
#Next imports are the metrics that we will be working with.
import json
import requests
import time

EXPORTER_PORT = 8001 # port number on which this exporter will run on. 8001.
SERVER = 'http://localhost:8000' # http address from where exporter will scrape the data

class CustomCollector(object):
  def __init__(self, endpoint):
    self._endpoint = endpoint

  def collect(self):

    response = json.loads(requests.get(self._endpoint).content.decode('UTF-8'))
    # generator: Generators are iterators, a kind of iterable you can only iterate over once. Generators do not store all the values in memory, they generate the values on the fly:
    #  mygenerator = (x*x for x in range(3))
    #  for i in mygenerator:
        #print(i)

    #yield is a keyword that is used like return, except the function will return a generator.
    #the function continues to go on

    yield CounterMetricFamily('visitors_served_total', 'App visitors served total', value=response['visitors_served'])
    # inside CounterMetricFamily, first we have the metric name for this metric, which is visitors_served_total.
    #And then the next parameter is the metric help string.Then the actual metric value, which was collected
    #from the above response with the keyname visitors served.

    traffic_metric = GaugeMetricFamily('traffic_channel', 'Traffic channel source', labels=['source']) # here we are looping in traffic_channel multi-dimentional array 
    for k, v in response['traffic_channel'].items():
      traffic_metric.add_metric([k], value=v)
    yield traffic_metric

if __name__ == '__main__':

    start_http_server(EXPORTER_PORT)
    REGISTRY.register(CustomCollector(SERVER)) #the register method from registry is involved, passing the custom collector class to add this collector to the registry.
    while True: 
        time.sleep(1)

