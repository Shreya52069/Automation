sentence = "this is my pen"
#output = siht si ym nep
l = sentence.split()
newsen = ''
for word in l:
    neww = word[::-1]
    print(neww)
    newsen +=  ''.join(neww + ' ')
print(newsen)