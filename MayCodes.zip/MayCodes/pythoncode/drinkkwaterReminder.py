import  win32com.client as wincom
import time

speak = wincom.Dispatch("SAPI.SpVoice")
timenow = time.time()
for i in :
    text = "Time for a break. Go drink some water."
    speak.Speak(text)
    timenow + 7200
    s = strftime("%a, %d %b %Y %H:%M:%S",
             gmtime(timenow))

# 3 second sleep

#Regular expressions
