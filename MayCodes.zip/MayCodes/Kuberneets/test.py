x = input("Enter the number: ")
y = int(x)

if y%3 == 0 and y%5 == 0:
    print("fizzbuzz") 
elif y%3 == 0:
    print("fizz")
elif y%5 == 0:
    print("buzz")
