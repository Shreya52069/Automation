import requests
from bs4 import BeautifulSoup #scrapping static websites

url = "https://medium.com/"
response = requests.get(url)
#print(response.text)
#print("                                                     lalalalalal                    lalalalal             lalalala")

soup = BeautifulSoup(response.text, 'html.parser')
#print(soup.prettify)
for heading in soup.find_all("h2"): #finding all h2 tags
    print(heading.text)
