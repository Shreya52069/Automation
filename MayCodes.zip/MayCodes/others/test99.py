#198.162.0.1 , 8023

#https://198.162.0.1:8023/api/v1
#ip = input("Enter ip address:")
#port = input("")

def newstring(ip, port):
    listofzeros = ["0","00","000"]
    if ip.__contains__(":"):
        iplist = ip.split(":")
        for i in iplist:
            print(i)
                #print(i)
                #i.replace(i, )
            for char in range(len(i)):
                print(char)

        n = "https://["+ip+"]:"+str(port)+"/api/v1"
        return n
    else:
        newstr = "https://"+ip+":"+str(port)+"/api/v1"
        print(newstr)
        return newstr

obj = newstring("198.162.0.1",8023)
print(obj)
obj1 = newstring("2607:f2b1:5609:0604:1::5", 8023)
print(obj1)
