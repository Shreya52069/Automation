def bubble(arr):
    l = len(arr)
    sorted = False
    while not sorted:
        sorted = True
        for i in range(0, l-1):
            if arr[i] > arr[i+1]:
                sorted = False
                arr[i+1], arr[i] = arr[i], arr[i+1]
    return arr
print(bubble([2,4,6,1,5,7]))