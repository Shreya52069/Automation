def compare_files(file1, file2):
    with open(file1, 'r') as f1, open(file2, 'r') as f2:
        lines1 = f1.readlines()
        lines2 = f2.readlines()

    max_length = max(len(lines1), len(lines2))
    differences = []

    for i in range(max_length):
        line1 = lines1[i].strip() if i < len(lines1) else None
        line2 = lines2[i].strip() if i < len(lines2) else None
        if line1 != line2:
            differences.append((i, line1, line2))

    return differences

# Example usage:
file1 = 'file1.txt'
file2 = 'file2.txt'
diffs = compare_files(file1, file2)
for line_num, line1, line2 in diffs:
    print(f"Line {line_num}: {line1} != {line2}")
