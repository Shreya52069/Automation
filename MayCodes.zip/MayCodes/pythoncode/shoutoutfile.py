import win32com.client as wincom

# you can insert gaps in the narration by adding sleep calls
import time

speak = wincom.Dispatch("SAPI.SpVoice")
list = ["Shreya", "Gauri", "Akshay"]
for i in list:
    text = "Shout out to"+ i
    speak.Speak(text)

# 3 second sleep
#time.sleep(3) 

#text = ""
#speak.Speak(text)
