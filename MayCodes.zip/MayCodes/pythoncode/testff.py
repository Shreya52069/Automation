def palindrome(st):
    print(len(st)-1//2)
    mid = (len(st) -1)//2
    start = 0
    end = len(st)-1
    flag = 0
    while start <= mid:
        if st[start] == st[end]:
            start += 1
            end -+ 1
        else:
            flag = 1
            break
palindrome("helloolleh")    
def symmetrical(s):
    mid = len(s)//2
    m = (len(s)-1)//2
    start = 0
    end = len(s)-1
    flag = 1
    print(len(s)%2)
    while start <= m:
        print(s[start])
        print(s[mid])
        if s[start] == s[mid]:
            print(s[start])
            print(s[mid])
            start += 1
            mid += 1
        else:
            flag = 1 
            break
    print(flag)

symmetrical("knokno")