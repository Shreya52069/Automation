with open('C:\Shreya_personal\Python\MayCodes\pythoncode\practish.py', 'r') as g:
    g.seek(10)
    data = g.read(5)
    print(data)