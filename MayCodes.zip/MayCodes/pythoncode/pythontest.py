import requests
import json

url = "https://newsapi.org/v2/everything?q=apple&from=2023-08-04&sortBy=popularity&apiKey=7882a63a0e254caf95b4aac7f8f425c1"
res = requests.get(url)
news = json.loads(res.text)
print(news)