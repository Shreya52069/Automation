import string
nline = "Helo shreya, hi shreya, hello shreya. You are great. you are amazing"

def remove_punctuation(text):
    return ''.join([char for char in text if char not in string.punctuation])

line = remove_punctuation(nline)
d = {}
for word in line.split():
    w = word.casefold()
    if w in d:
        d[w] = d[w] + 1
    else:
        d[w] = 1
print(d)

import threading
import time
def one():
    print("hello")
    time.sleep(10)
    print("end1")
def two():
    print("in two")
    time.sleep(5)
    print("end of two")
thread1 = threading.Thread(target=one)
thread2 = threading.Thread(target=two)
thread1.start
thread2.start
thread1.join()
thread2.join()