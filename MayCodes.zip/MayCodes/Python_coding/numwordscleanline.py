import string
def cleanline(line):
    return ''.join([char for char in line if char not in string.punctuation])
print(cleanline("Hello! lalala, lalala, hahaha."))

def countwords(line):
    cline = cleanline(line)
    clinelist = cline.split()
    dictcount = {}
    for word in clinelist:
        if word in dictcount:
            dictcount[word] += 1
        else:
            dictcount[word] = 1
    return dictcount
print(countwords("Hello! lalala, lalala, hahaha."))