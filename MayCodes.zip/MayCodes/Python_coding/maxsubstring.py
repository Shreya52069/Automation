def uniquesubstring(st):
    charSet = set()
    l = 0
    res = 0
    for r in range(len(st)):
        while st[r] in charSet:
            charSet.remove([st[r]])
            l += 1
        charSet.add(st[r])
        res = max(res, r-l+1)
    return res
