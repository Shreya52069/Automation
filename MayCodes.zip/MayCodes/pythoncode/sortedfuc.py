d = {'a':10, 'b':6, 'e': 8}
print(sorted(d.items()))
#sorted(iterable, key=None, reverse=False)

numbers = [5, 2, 9, 1, 5, 6]
sorted_numbers = sorted(numbers)
print(sorted_numbers)

fruits = ["banana", "apple", "cherry", "date"]
sorted_fruits = sorted(fruits)
print(sorted_fruits)  # Output: ['apple', 'banana', 'cherry', 'date']

numbers = [5, 2, 9, 1, 5, 6]
sorted_numbers_desc = sorted(numbers, reverse=True)
print(sorted_numbers_desc)  # Output: [9, 6, 5, 5, 2, 1]

fruits = ["banana", "apple", "cherry", "date"]
sorted_fruits_by_length = sorted(fruits, key=len)
print(sorted_fruits_by_length)  # Output: ['date', 'apple', 'banana', 'cherry']

# Define a custom function
def custom_sort(value):
    return value % 3
numbers = [5, 2, 9, 1, 5, 6]
sorted_numbers_custom = sorted(numbers, key=custom_sort)
print(sorted_numbers_custom)  # Output: [9, 6, 5, 5, 2, 1]

students = [("Alice", 22), ("Bob", 19), ("Charlie", 23)]
sorted_students_by_age = sorted(students, key=lambda student: student[1])
print(sorted_students_by_age)
# Output: [('Bob', 19), ('Alice', 22), ('Charlie', 23)]

students = [("Alice", 22), ("Bob", 19), ("Charlie", 23), ("Bob", 22)]
# First by name, then by age
sorted_students_by_name_then_age = sorted(students, key=lambda student: (student[0], student[1]))
print(sorted_students_by_name_then_age)
# Output: [('Alice', 22), ('Bob', 19), ('Bob', 22), ('Charlie', 23)]

grades = {'Alice': 85, 'Bob': 92, 'Charlie': 78}
sorted_keys = sorted(grades)
print(sorted_keys)  # Output: ['Alice', 'Bob', 'Charlie']


grades = {'Alice': 85, 'Bob': 92, 'Charlie': 78}
sorted_by_value = sorted(grades, key=lambda key: grades[key])
print(sorted_by_value)  # Output: ['Charlie', 'Alice', 'Bob']


sorted_items = sorted(grades.items(), key=lambda item: item[1])
print(sorted_items)  # Output: [('Charlie', 78), ('Alice', 85), ('Bob', 92)]


string = "python"
sorted_chars = sorted(string)
print(sorted_chars)  # Output: ['h', 'n', 'o', 'p', 't', 'y']

sentence = "Sorting words in a sentence can be fun"
words = sentence.split()
sorted_words = sorted(words)
print(sorted_words)
# Output: ['Sorting', 'a', 'be', 'can', 'fun', 'in', 'sentence', 'words']

fruits = ["Banana", "apple", "Cherry", "date"]
sorted_fruits_case_insensitive = sorted(fruits, key=str.lower)
print(sorted_fruits_case_insensitive)
# Output: ['apple', 'Banana', 'Cherry', 'date']



employees = [
    {"name": "Alice", "age": 30, "salary": 70000},
    {"name": "Bob", "age": 25, "salary": 50000},
    {"name": "Charlie", "age": 35, "salary": 120000},
]

# Sort by salary
sorted_employees = sorted(employees, key=lambda e: e["salary"])
print(sorted_employees)
# Output: [{'name': 'Bob', 'age': 25, 'salary': 50000}, {'name': 'Alice', 'age': 30, 'salary': 70000}, {'name': 'Charlie', 'age': 35, 'salary': 120000}]



class Car:
    def __init__(self, brand, year):
        self.brand = brand
        self.year = year

    def __repr__(self):
        return f"{self.brand} ({self.year})"

cars = [Car("Toyota", 2018), Car("Honda", 2020), Car("Ford", 2016)]

# Sort by year
sorted_cars_by_year = sorted(cars, key=lambda car: car.year)
print(sorted_cars_by_year)
# Output: [Ford (2016), Toyota (2018), Honda (2020)]

# Sort by brand name
sorted_cars_by_brand = sorted(cars, key=lambda car: car.brand)
print(sorted_cars_by_brand)
# Output: [Ford (2016), Honda (2020), Toyota (2018)]



from operator import itemgetter

students = [("Alice", 22), ("Bob", 19), ("Charlie", 23), ("Bob", 22)]
# Sort by name, then by age
sorted_students = sorted(students, key=itemgetter(0, 1))
print(sorted_students)
# Output: [('Alice', 22), ('Bob', 19), ('Bob', 22), ('Charlie', 23)]


from operator import attrgetter

class Car:
    def __init__(self, brand, year):
        self.brand = brand
        self.year = year

    def __repr__(self):
        return f"{self.brand} ({self.year})"

cars = [Car("Toyota", 2018), Car("Honda", 2020), Car("Ford", 2016)]

# Sort by year
sorted_cars = sorted(cars, key=attrgetter('year'))
print(sorted_cars)
# Output: [Ford (2016), Toyota (2018), Honda (2020)]

