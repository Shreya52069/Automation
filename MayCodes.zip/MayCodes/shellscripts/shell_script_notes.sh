#!/bin/bash -- this is called "sharp bang or shebang"
#first line starts with a shebang, - what follows the shebang is used as the interpreter for the commands listed in the script.
For example- #!/bin/csh or #!/bin/bash
#When you execute a script that contains a shebang, what actually happens is that the interpreter is executed and the path used to call the script
#is passed as an argument to the interpreter.
Imp:
#If you do not supply a shebang and specify an interpreter on the first line of the script,
#the commands in the script will be executed using your current shell. Even though this can work just fine under many circumstances,
#it's best to be explicit and specify the exact interpreter to be used with the script.

#For example, there are features and syntax  that work just fine with the bash shell that won't work with the csh shell.

We can run python scripts by not just python3 hi.py but also by providing the intrepretor in the script and running the script like-
./hi.py

Provide thw intrepreter on the first line of the script- #!/usr/bin/python
#variables:
Variables are case sensitive
By convention- variables are uppercase
VARIABLE_NAME="valuee"
# to declare interger variables.
declare -i x=10

#to perform arthemtic operations- 
$(($NUMBER+1))

Imp:
MY_SHELL="bash"
echo "I like the  $MY_SHELL shell."

echo "I like the ${MY_SHELL} shell."  # this is better when we want to add additional data
#for example-
echo "I like the ${MY_SHELL}ing on my keyboard" # here ing will be added to the value of the variable but had it been
echo "I like the  $MY_SHELLing shell." #then the shell will treat the additional text as part of the variable name. 
#Since a variable with that name does not exist, nothing is put in its place 

# assiging output of a command to a variable
SERVER_NAME=$(hostname) # output of command hostname is stored in the variable
# the above can also be done using ``
SERVER=`hostname` 

#Tests
#To create a test place a conditional expression between brackets. The syntax is: [ condition-to-test-for ].
example- [-e /etc/passwd] # this one checks if /etc/passwd exists - if yes- return true and exit ststaus is 0 otherwise it is 1

#File test operators
-d FILE     True if file is a directory
-e FILE     True if file exists
-f FILE     True if file exists and is a regular file and not a symlink 
-r FILE     True if file is readable by your
-s FILE     True if file exists and is not empty
-w FILE     True if the file is writable by you
-x FILE     True if file is executable by you

#string 
-z string   True if string is empty
-n STRING   True if string is not empty
STRING1 = STRING2 True if string are equal
STRING1 != STRING2 True is string are not equal

#arthematic tests
arg1 -eq arg2 True if arg1 is equal to arg2
    - ne not equal to
    -lt less than
    -le less than or equal to
    -gt greater than
    -ge greater than or equal to

#contionals
if [condition-is-true]
then
    command 1
    command2
fi

#
if [condition-is-true]
then
    command 1
    command2
else
    command3
fi

#
if [condition-is-true]
then
    command 1
    command2
elif [Contionton]
then
    command 4
else
    command 5
fi

#for loop
for VARIABLE_NAME in ITEM1 ITEM_N
do
    command 1
    command2
done

#!/bin/bash
PICS=$(ls *jpg)
DATE=$(date +%F) # format- 2023-08-11
for Pic in $PICS
do 
    echo "Renaming ${Pic} to ${DATE}_${Pic}"
    mv ${Pic} ${DATE}_${Pic}
done

script.sh parameter1 parameter2 parameter3 parameter4
$0 is "script.sh"
$1 is "parameter 1"
$2 is "parameter 2"
..
..
#!/bin/bash
USER=$1
echo "executing script: $0"
echo "Archiving user: $USER"
# lock the account
passwd -l $USER
#archiving home directory of user
tar cf /archives/${USER}.tar.gz /home/${USER}

---- another way of doing it for multiple user-
# in order to access all command line parameters passed to the script use- "$@" - 
#this operator will help in accessing from forst to last all passed parameters

example-
echo "Executing script: $0"
for USER in "$@"
do 
    echo "Archiving user: $USER"
    passwd -l $USER
    tar cf /archives/${USER}.tar.gz /home/${USER}
done

#Accepting standard input
read -p "PROMPT" VARIABLE
#example- 
read -p "Enter a user name: " USER
echo "Archiving user $USER"

#EXIT STATUS
Range from 0 to 255
0 = success
other than 0 = error
use man or info to find the meaning if exit STATUS

ls /nt/here
echo $?
if [ "$?" -eq "0" ]  # note that spaces are very important. - else error
then
    echo "Not present"
fi
$HOST="google.com"
ping -c 1 $HOST
RETURN_CODE=$?
if ["$RETURN_CODE" -ne "0"]
then
    echo "$HOST unreachable"
fi


&& - and
mkdir /tmp/bak && cp test.txt /tmp/bak
#the command following a double ampersand will only run if the previous command exits with a 0 exit status.
# second command will only run if first one runs with exit code 0
|| - or
#The command following a double pipe will only execute if the previous command fails.
#If the first command returns a non-zero exit status, then the next command is executed.
#If first command succeeds, then second command wont run
$HOST="google.com"
ping -c 1 $HOST && echo "$HOST reachable"

#The semicolon
Separate commands with a semicolon to ensure they all get executed.
cp test.txt /tmp/bak; cp test.txt /tmp
#The semicolon does not check the exit status of the previous command.
#The command following a semicolon will always get executed, no matter if the previous command failed or succeeded.

We can explicitly define exit code for out shell script.
We can define it from 0 to 255- if we dont then exit command of the last command executed is used as the exit status 

#!/bin/bash
HOST="google.ocm"
ping -c 1 $HOST
if ["$?" -ne "0"]
then
    echo "$HOST unreachable"
    exit 1
fi 
exit 0

This shell script can be called by any other shell script and its exit status can be examined.

#Since you control the exit statuses, you can make them have a significant meaning.
Maybe a return code of 1 means that one type of error occurred
while a return code of 2 means that a different type of error occurred.
If you have scripts that are executing other scripts, then you can program accordingly
to these returns codes if you need or want to.

#FUNCTIONS
Dont repeat yourself(DRY)
2 ways of reating a FUNCTION:

1. function fucntion-name(){
    #code goes here
}
function-name(){
    #Core goes here
}

function hello(){
    echo "hello"
}
hello


# functions can call other fucntions
#!/bin/bash
function hello(){
    echo "Hello"
    now # this is read before so will execute file
}
function now()
{
    echo "It is $(date +%F)"
}
hello

fucntions hello(){
    echo "Hello"
    now
}
hello # this will throw an error
function now()
{
    echo "It is $(date +%F)"
}
#by default Variables are global- but variables are to be defined before use
any variable defined before a fucntion will be accessible to the funtion- 
any variable defined after the fucntion defination will not be accessible to the fucntion

any variable defined in the function will not be availble until we call the fucntionafter calling the function- it will be available

myfunc(){
    VAR=1
}
echo $VAR # wont be available- empty line printed
myfunc
echo $VAR #Now it will be available

#local variable - variable only accessed within the fucntion
use local keyword before the var
Only fucntions can have local variables

#fucntions also have exit status
Explicitly you can define using
return <RETURN_CODE>
Implicitly-
the exit status of the last command executed in the funtions

example:
fucntion backup(){
    if [ -f $1 ]
    then
        local BACK="/tmp/$(basename ${1}).$(date +%F).$$" #basename is a command which emoves any leading directory components and returns just the file name.
        #$$ represents the PID or process ID of the currently running shell script.
        echo "Backing up $1 to ${BACK}"
        cp $1 $BACK
    else
        return 1
    fi
}
backup /etc/hosts
if [ $? -eq 0 ]
then
    echo "Backup succeeded"
else
    echo "Backup failed"
    exit 1
fi

#shell script order
1. shebang
2. Commants describing what is in the shell script
3. functions
    use local variables
4. MAin script contents
5. Exit with an exit status

#wildcards
A character or string used to for pattern matching
Globbing expands the wildcard pattern into a list of files or Directories
wildcards can be used with common commands like ls, rm, cp
You can use wildcards to create search patterns that when expanded will return a list of matching files and directories.
Sometimes wildcards are referred to as globs or glob patterns. Globbing is the act of expanding a wildcard
into the list of matching files and directories.

* - matches zero or more characters
?- matches one character
#he question mark matches exactly 1 character.
#If you want to find all the files that only have 1 character preceeding .txt,
#then use ?.txt
[] -A character class
matches any characters included b/w the brackets. Matches one character
[aeiou]
can[nt]*
[!]- matches any of the characters not included b/w the brakets. Matches exactly one character
[!aeiou]* -for example - any file taht doesnt start with a vowel.
We can also create a range-
[a-g]*
[3-6]
We also have pre-defined ranges
[[:alpha:]] - matches both lower and upper case letters
[[:alnum:]] - matches alpha and digits
[[:digit:]]
[[:lower:]]
[[:space:]]
[[:upper:]] -matches upper case letters

\ -escape character: use if you want to match a wildcard character.
Match all files that end with a question mark  *\?
We do this so that it doesnt see the ? as a wildcard whcih matches one character

ls -F - gives details- whcih is a dir , whichis a file

#using wildcards in shell scripts

cd /var/www
for FILE in *.html
do
    echo "Copying $FILE"
    cp $FILE /var/www-just-html
done

or you cando- will print the entire path
for file in /var/www/*.html
do
    echo "Copying $file"
    cp $FILE /var/www-just-html
done

#CASE statements
Alternative to if statements
if ["$VAR" = "one"]
elif ["$VAR" = "two"]
elif ["$VAR" = "three"]
elif ["$VAR" = "four"]

insuch senarios - case will be easier to read

case "$VAR" in
    pattern_1)
        #Commands go here
        ;;
    pattern_N)
        #Commands go here
        ;;
esac

example-
case "$1" in
    start)
        /usr/sbin/sshd
        ;;
    stop)
        kill $(cat /var/run/sshd.pid)
        ;;
esac
#####

case "$1" in
    start)
        /usr/sbin/sshd
        ;;
    stop)
        kill $(cat /var/run/sshd.pid)
        ;;
    *)  # wildcard- matches anything
        echo "Usage: $0 start|stop" ; exit 1 #anything other than "start" and "stop" will cause the last pattern to be matched. In that case, the echo and exit commands will be executed.
        ;;
esac

####
read -p "Enter y or n: " ANSWER
case "$ANSWER" in
    [yY]|[yY][eE][sS])
        echo "You answered yes"
        ;;
    [nN]|[nN][oO])
        echo "you answered no"
        ;;
    *)
        echo "Invalid answer"
        ;;
esac
####
read -p "Enter y or n: " ANSWER
case "$ANSWER" in
    [yY]*)              # anything that starts with y or Y is considered 
        echo "You answered yes"
        ;;
    *)
        echo "you answered something else"
        ;;

#logging and syslogs
#logs are the who, what, when, where and why

#syslogs-The Linux operating system uses the syslog standard for message logging. This allows programs and applications
#to generate messages that can be captured, processed, and stored by the system logger.
#It eliminates the need for each and every application having to implement a logging mechanism.
#That means we can take advantage of this logging system in our shell scripts.

How syslogs works-
The syslog standard uses facilities and severities to categorize messages.
Each message is labeled with a facility code and a severity level.
The various combinations of facilities and severities can be used to determine how a message is handled.
Facilities are used to indicate what type of program or what part of the system
the message originated from. For example, messages that are labeled with the kern facility
originate from the Linux kernel.
Messages that are labeled with the mail facility come from applications involved in handling mail.

If your script is involved in handling mail, you could use the mail facility for logging.

If its not clear what facility to use, you can simply use the user facility.
Also, the facilities ranging from local0 to local7 are to be used to create custom logs.
These facilities would also be appropriate for custom written shell scripts.
The severities are emergency, alert, critical, error, warning, notice, info, and debug.

These combinations of facilities and severities are used by the system logger to handle these messages. Most messages are simply written 
to a file. Each distribution uses a slightly different set of defaults, and these logging rules are configurable
and can be changed.
You'll' find many messages stored in /var/log/messages on some distributions
while others use /var/log/syslog, for example.
You'll' have to consult the documentation for the system logger that is in use on your system.
It's' typically one of syslogd, rsyslog, or syslog-ng, although there are several other possibilities.

#We can use logging in our shell scripts using logger command
The logger command generates syslog messages. In its simplest form you simply supply a message to the logger utility.
By default, the logger utility creates messages using the user facility and the notice severity.

logger "Message"
logger -p local0.info "Messgae" #If you want to specify the facility and severity, use the -p option
logger -t myscript -p local0.info "Message" # tag your message use -t. ussually you wanna tag it in your script name- to extract mesages of your script
logger -i -t myscript "Message" # if you wanna include the pid in the log message use -i

#Remember that different facilities and severities can cause the system logger to route the messages to a 
different log file. If you want to display the message to the screen in addition to sending it
to the logging system use the -s option.

#If multiple copies of your script can run at the same time, then having a PID can help differentiate the logs
being generated by one instance of the script vs logs being generated by another instance of the script

# you can create a fucntion in your shell script to handel logging

logit(){
    local LOG_LEVEL=$1
    shift       imp \#shift the positional parameters to the left. This means that the special variable $@ contains everything but the first positional parameter
    MSG=$@
    TIMESTAMP=$(date +"%Y-%m-%d %T")
    if [ $LOG_LEVEL = 'ERROR' ] || $VERBOSE # If VERBOSE global variable is set to "TRUE",
    then
        echo "${TIMESTAMP} ${HOST} ${PROGRAM_NAME} [${PID}] : ${LOG_LEVEL} ${MSG}"
        logger 
    fi
}
logit INFO "Processing data"

#While loops
while loop is a loop that repeats a series of commands for as long as a given condition is true. 

while [condition is true]
do
    command1
    command 2
    command n
done

while true - infinite loop

INDEX=1
while [$INDEX -lt 6]
do
    echo "creating project- ${INDEX}"
    mkdir /usr/local/project-${INDEX}
    ((INDEX++)) #mathematical expressions g inside double parantheses
done

## an application is running when it stops we come out of the loop
while ping -c 1 app1 >/dev/null # -c 1 makes sure we send only one packet to the server app1 and stop the ping command
do
    echo "App running.."
    sleep 5
done
echo "App down"

#for loop reads a file word by word
# to read a file line by line use while with read command

LINE_NUM=1
while read LINE
do 
    echo "${LINE_NUM}: ${LINE}"
    ((LINE_NUM++))
done < /etc/fstab   #

#another way of doing this
grep xfs /etc/fstab | while read LINE
do
    echo "xfs: ${LINE}"
done
####

FS_NUM=1
grep xfs /etc/fstab | while read FP MP returns  # we have 3 variables where first word in first var, second word in second var and remaining all chrs in last var
do
    echo "${FS_NUM}: file system ${FP}"
    echo "${FS_NUM}: mount Point ${MP}"
    ((FS_NUM++))
done

#If you want to exit a loop before its normal ending, use the break statement. The break statement exits the loop, but
#it does not exit the script. 

# if you want to restart the loop at the next iteration before the loop completes, use the continue statement. Any commands that follow the continue
#statement in the loop will not be executed. Execution continues back at the
#top of the loop and the while condition is examined again.

mysql -BNe 'show database' | while read DB
do
    db-backed-up-recently $DB
    if [ "$?" -eq "0" ]
    then
        continue
    fi
    backup $DB  # will not be executed until if condition is false and ocntinue is not executed
done

#################################
#debugging
We have some Built-in funtions in bash which help us debug scripts

#!/bin/bash -x
The '-x' option prints commands and their arguments as they are executed.
This means that, instead of variables being displayed, the values of those variables are displayed.
The same thing goes for expansions. Wildcards aren't displayed, but what they expand to is displayed.

If you want to do this at the command line, run 'set -x'(This will start the x-trace). Use 'set +x' to stop this debugging behavior.
You can also use this option for just a portion of your script.
Just before you want to start displaying the commands to the screen, add a 'set -x line'.
Place 'set +x' on a line after the section of the shell script that you're debugging.

#!/bin/bash -x
TEST_VAR="test"
echo "$TEST_VAR"

#!/bin/bash

TEST_VAR="test"
set -x
echo $TEST_VAR
set +x
hostname


### another option to find errors in scripts is -e option
It causes your script to exit immediately if a command exits with a non-zero exit status.
#!/bin/bash -ex
#!/bin/bash -xe
#!/bin/bash -e -x
#!/bin/bash -x -e
all above are same

# another option  is -v option
It prints the shell commands just like they are read in from the script.
'-v' prints everything before any substitutions and expansions are applied. The -x option performs variable and wildcard expansion,
but the -v option does not. You can use them in combination to see what a line looks like before and after
substitutions and expansions occur.
we can see the how a command looks in the shell script and how it actually gets executed.

NOTE- any man or help command pip through less so that you can easily scroll up and down in the doc
######################

if you want a bit more control around debugging, you can create your own code to do it.
One method I personally use is to create a variable called DEBUG.
I set this to true if I'm currently debugging or false if I'm not.
DEBUG=true #this is a boolean value
if $DEBUG
then
    echo "debug mode is on"
fi

$DEBUG && echo "debug mode is on"

Note- when $DEBUG is set to false and we run 
$DEBUG-the exit code is non zero
$DEBUG || echo "Debug mode off"

#!/bin/bash
debug(){
    echo "Executing $@"
    $@
}
debug ls # here we are running all commands passed to the compiler
#you could write this information to a log file and include time stamps showing exactly when each command was executed.

Note-
When we use -x in front of #!/bin/bash 
the defualt value which is printed infront of the line is +, here value of PS4 is +
PS4 is a command which can control what is displyed before a line when using -x option

Bash has some built in variables like $BASH_SOURCE, which is the name of the script itself, $LINENO, which is the line number in the script, etc.
we can set PS4 to this
PS4='+ $BASH_SOURCE : $LINENO'

another thing can be where we also get the funtion name 
PS4='+ ${BASH_SOURCE} : ${LINENO} : ${FUNCNAME[0]}()'

Plain text files, like we are working with for shell scripts, contain a control character
to represent the end of a line. For Unix and Linux systems,
the control character representing a new line is a Line Feed.
DOS or Windows systems actually use two characters to represent a new line:

When we create a file in linux and send it to windows- we will get the content of file in one single line
because of lack of carriage returns
and we create a file in windows and send to linux we get extra characters- specifically carriage returns 

NOTE- when we display the contents of the file to the screen, we dont see the carriage returns- when we do cat file.txt - wont see 
but when we do "cat -v file.txt" -To display non-printable characters, like carriage returns.

Carriage returns are represented by the caret symbol followed by M (^M).
If you were to execute a file that contains carriage returns,
you'll probably run into an error like this: /bin/bash^M:, No such file or directory.

Instead of cat -v command you can use file command
file script.sh

To remove these characters- use dos2unix script.sh
to make it from unix to dos use unix2dos

##############
sed stands for Stream editor
A stream is data that travels from one place to another through a pipe, one file to another as a redirect or one device to another
The sed command is used to perform basic text transformations on an input stream.

Use sed to substitute some text for other text, remove lines, append text after given lines and insert text before certain lines.

in a file the content is -Dwight is the assistant regional manager.
for example- we want to substitute "assistant" with "assistant to the"
sed 's/assistant/assistant to the/' manager.txt # here s stands for substitution - the /regular expression to find word/subtitued string

NOTE: sed is not changing anything in the file, rather it is printing the change via stdout on the terminal
Also sed is case sensitive

sed 's/my wife/sed/' love.txt

sed 's/serach-pattern/replacement-string/flags'
i flag- insensitive
sed 's/MY WIFE/sed/i' love.txt

NOTE- when we do - echo 'I love my wife' > love.txt #creates the file
echo 'this is like 2' >> love.txt # this appends to the file and not replace the original content

sed command changes where ever it finds the pattern until we reach end of the file
If the search pattern is present multiple times in one line, only first occurance is changed
to avoid this from happening- we can use g flag
if you want to only change the second occurance of the sting and not any other use 2 as the flag
sed 's/my wife/sed/2' love.txt

# When you want to change contents of a file and store it in new file-
sed 's/my wife/sed/g' love.txt > my-new-love.txt

Another thing sed can do is make changes to your original file and create a backup file with previous content

sed -i.bak 's/my wife/sed/g' love.txt

#if you wanna save only those lines where matches were made use w 
sed 's/love/like/gw like.txt' love.txt

# sed can also be used in a pipe
cat love.txt | sed 's/wife/haha/'

echo /home/jason | sed 's\/home\/jason/\/exports\/users\/jason/'        # escaping / by \
The avobe line is too long- we can use anything else as a delimeter-
for example instead of / we use #
sed 's#/home/jason#/exports/users/jason#'

#delete lines with sed using d 
sed '/This/d' love.txt # the line that starts with This will be deleted

 NOTe- examples for sed usage- migrating servers, when using restore of one server to create another server- changing hostnames in /etc/hosts or any other config
 When using clusters- changing hostnames
 
 # removing comments from a file
 sed '/^#/d' config.txt # search string is a regular expression - ^ signifies starting of a line- any line starting with

 To remove empty lines-
 sed '/^$/d' config.txt # here $ means end of a line

 We cna have the above two expressions together using semicolon
 sed '/^#/d ; /^$/d' config

 you can also use multiple -e to run multiple commands
 sed -e '/^#/d' -e '/^$/d' -e 's/apache/httpd/' config.txt


 We can also have all sed arguments in a file and pass that to sed
 sed -f scripts.sed config.txt

 # addresses- An address determines on what lines the sed command will be executed on if no address is given, the command is performed on all lines.
 sed '2 s/httpd/apache/' config.txt # here 2 is line number- we can also remove the space between 2 and s
 # we can also use regular expressions for sed command-
 for example- Lets say you want to replace Apache with Httpd, but only on lines that contain the word group.
 sed '/Group/ s/apache/httpd' config.txt

example- For example, if we wanted to change the word run to execute, but only on lines one through three,
sed  '1,3 s/run/execute/' config.txt

Lets say we want to change run to execute, starting with the line that matches "#" user and ending at the next blank line.
sed '/#User/,/^$ s/run/execute/' config.sh