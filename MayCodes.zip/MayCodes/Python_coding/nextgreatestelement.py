def nextgrestestelement(nums):
    n = len(nums)
    res = [-1]* n
    stack = []
    for i in range(n):
        while stack and nums[i] > nums[stack[-1]]:
            index = stack.pop()
            print(index)
            res[index] = nums[i]
        stack.append(i)
        print(stack)
    return res

print(nextgrestestelement([5,3,1,2,4,6]))