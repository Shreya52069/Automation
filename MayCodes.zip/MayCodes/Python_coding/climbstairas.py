#how many ways of climing to reach final stair
def climbstairs(n):
    one, two = 1,1
    for i in range(n-1):
        temp = one
        one = one + two
        two = temp
    return two

#climbstairs(5)
print(climbstairs(6))

def climbwithmoney(cost: list):
    cost.append(0)
    for i in range(len(cost)-3, -1, -1):
        cost[i] = min(cost[i]+cost[i+1], cost[i]+cost[i+2])
    return min(cost[0], cost[1])
print(climbwithmoney([10,15,20]))
print(climbwithmoney([1,100,1,1,1,100,1,1,100,1]))

def robber(nums):
    rob1, rob2 = 0,0
    for n in nums:
        temp = max(n+rob1, rob2)
        rob1 = rob2
        rob2 = temp
    return rob2
#def decodeways(self, s):
    