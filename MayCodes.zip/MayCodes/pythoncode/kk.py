class test:
    def __init__(self, n, k):
        self.k = k
        self.n = n
    def t(self):
        print(self.k)
        print(self.n)
ob = test("jjj", "lll")
ob.t()