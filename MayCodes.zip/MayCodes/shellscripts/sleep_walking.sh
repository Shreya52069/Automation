#!/bin/bash
read -p "Would you like to start or stop the sleepwalking app?: " ANSWER
case "$ANSWER" in
    [sS]tart)
        sh /tmp/sleepwalkingserver
        ;;
    [sS]top)
        kill $(cat /tmp/sleep­walking­server.pid)
        ;;
    *)
        echo "Invalid input"
        ;;
esac





#in /tmp store a file called sleepwalkingserver with content

#!/bin/bash
PID_FILE="/tmp/sleep­walking­server.pid"
trap "rm $PID_FILE; exit" SIGHUP SIGINT SIGTERM
echo "$$" > $PID_FILE
while true
do    
  :
done