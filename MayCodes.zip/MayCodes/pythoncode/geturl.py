import json

file = open("C:\Users\Shreya_Bhardwaj\OneDrive - Dell Technologies\CopySync_20240310174306\Edge Bookmarks\Bookmarks", "r")
data = json.loads(file)
for i in data:
    print(data['roots.children[i].url'])