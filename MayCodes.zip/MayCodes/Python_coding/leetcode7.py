class Solution:
    def reverse(self, x: int) -> int:
        # negative number
        newnum = 0 
        if x < 0:
            newnum = int(str(x)[1:][::-1]) * -1
        if x > 0:
            newnum = int(str(x)[::-1])
        if newnum > 2 ** 31 -1 or newnum < -2 ** 31:
            return 0
        return newnum