import string
import random

choice = input("What would you like to do? For encyption type 'e' and for decryption type 'd'")
if choice == "e":
    x  = input("Enter the word: ")
    if len(x) >= 3:
        N = 3
        z = x[0]
        randomstring = ''.join(random.choices(string.ascii_lowercase, k=N))
        y =x[1:]+z+str(randomstring)
        print(y)
        #y = x.split()
        #z = y[0]
        #for i in range(1, len(y)):
        #   z[i] = y[i]
    else:
        a = x[::-1]
        print(a)
elif choice == "d":
    x  = input("ENter the word: ")
    if len(x) >= 3:
        z = x[0:-4]
        y = x[-4]
        a = y+z
        print(a)
    else:
        a = x[::-1]
        print(a)
else:
    print("Wrong choice")