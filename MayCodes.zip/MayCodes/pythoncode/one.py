import sys
#import subprocess

def printname():
    name = sys.argv[1]
    print("hello",sys.argv[1])
    print("hello variable", name)
    print("hello format {}".format(name))
    print(f"hello fstring {name}")

def argument(lang):
    if lang == 'es':
        print('Hola')
    if lang == 'fr':
        print('Bonjour')

def trycatch(ast):
    try:
        print("in try")
        ast = int(ast)
        print("wont print")
    except:
        ast = 1
    print("Done: ast is",ast)

def retunfun(argu):
    return "Hello",argu #returns a list even for this single argument.

def argu(a,b):
    added = a+b
    return added
printname()
argument('fr')
trycatch('bob')
print(retunfun('shreya'))
print(type(retunfun('shreya'))) # returns tuple
x = argu(5,7)
print(x)


#loops
def breaksta():
    while True:
        line = input('>')
        if line.casefold() == 'done': #This method is similar to the lower() method, but the casefold() method is stronger, 
#more aggressive, meaning that it will convert more characters into lower case, and will find more matches when comparing two strings and both are converted using the casefold() method.
            break
        print(line)
    print('Done')

breaksta()

def conti():
    while True:
        print("Now in another function with continue statement")
        line = input('>')
        if line == "#":
            continue # with continue the iterator goes up and starts the loop again  
        if line == 'done':
            break
        print(line)
    print("Done with continue")
conti()

def forloop():
    for i in range(10):
        print(i)

forloop()

def logicfor():
    largest_so_far = -1
    print('Before Computation, ', largest_so_far)
    for i in [1,64,76,33,25,96,36,7,6,69]:
        if i > largest_so_far:
            largest_so_far = i
        print(largest_so_far)
    print("After, ", largest_so_far)

    zork = 0
    for i in [9,24,41,19,77,89]:
        zork = zork + i
        print(zork, i)
    
    zork = 0
    for i in [9,24,41,19,77,89]:
        zork = zork + 1
        print(zork, i)
    
    found = False
    print("Before found was", found)
    for i in [11,34,56,71,76,84,86,92,97]:
        if i == 86:
            found = True
        #print(found, i)
    print("After found is", found)

logicfor()
def findsmallest():
    smallest = None
    for small in [5,17,28,34,39,40,-2,4,7,-9,20,-22]:
        if smallest == None:
            smallest = small
        elif small < smallest:
            smallest = small
        
    print("Smallest nummer in list", smallest) 

findsmallest()

def letter(lett):
    fruit = lett
    for i in range(len(fruit)):
        lette = fruit[i]
        print(lette)
    
    for i in range(len(fruit)):
        letter = fruit[i-1]
        print(letter)
    index = 0
    while index < len(lett):
        letter = fruit[index]
        print(index, letter)
        index = index+1

    for i in range(5, 40, 2): #from 5 to 40 with a jump of 2.
        print(i)
    for l in fruit:
        print(l)
    count = 0
    for l in fruit:
        if l == "o":
            count = count + 1
    print("number of o's", count)
letter('broccoli')

def slicingStrings(slice11):
    print(slice11[0:4])
    print(slice11[6:7])
    print(slice11[6:20])
    print(slice11[:2])#  prints last 2 strings
    print(slice11[8:]) #prints 8th letter onwards
    print(slice11[:]) # prints entire string

    
    vowel=0
    for i in slice11:
        if i in ['a','e','i','o','u']:
            vowel = vowel + 1
    print("numeber of vowels: ",vowel)

    for i in slice11:
        if i in ['a','e','i','o','u']:
            print("vowel found", i)

    print(dir(slice11)) #printing builtin function of string

    print(slice11.capitalize())
    print(slice11.find('on'))

slicingStrings('dragonfruit')

def replac(name):
    greet = "Hello "+name
    print(greet)
    bye = greet.replace('Hello', 'Bye')
    print(bye)

replac("Shreya")

def stripp():
    x = "   Hi, whats up?   "
    print(x)
    y = x.rstrip()
    print(y)
    z = y.lstrip()
    print(z)
    k = z.startswith("Hi") #print true or false
    print(k)
    m = z.find(',') # prints position
    positionplus = z[m:9]
    print(m)
    print(positionplus)


stripp()

# files
def files():
    testfile = open('password_generator.py', 'r')
    count = 0
    for line in testfile:
        print(line)
        count = count + 1
    print(count)

    # reading file in one go
    data = testfile.read()
    print(len(data))
    print(data[:2])
    
    # to find something in a file
    for line1 in testfile:
        if line1.startswith("if __name__"):
            print(line)

    # removing extra \n as print adds extar \n after every line
    for line2 in testfile:
        line2  = line2.rstrip()
        print(line)
    
    for line3 in testfile:
        print(line3.rstrip())

    for line4 in testfile:
        if not line4.startswith("if __name__"):
            continue
        print()
files()

#def linuxcommand():

 #   version = subprocess.run(['python3', '--version'], capture_output=True, text=True)
  #  pyversion = version.stdout()
  #  versionnumber = pyversion.split(' ')
  #  nums = versionnumber[1].split('.')
  #  number = str(nums[0]+nums[1])

# lists
def listexamples():
    friends = ["one", "two", "three"]
    x = [1,[2,3], 4]
    y = []
    z = list()
    #Lists are mutable
    a = [1,4,7,9,44,66,87]
    a[3] = 8
    lenghta = len(a)
    print(range(len(a)))

    for i in range(len(friends)):
        friend = friends[i]
        print(friend)

    print(a[1:4])
    z.append("hello")  # imp
    z.append("Hola")
    z.pop(3) # to delete an item in list

    b = 'Shreya' in friends
    print(b)
    c = 'four' not in friends
    print(c)
    a.sort() # sort function only sorts the list in place- if we want the list to be sorted we use sorted function and assign that to a new list
    print(max(a))
    abc = "Hello Shreya Bhardwaj"
    stuff = abc.split()
    print(stuff)
    bcs = "One;two;ka;four"
    fun = bcs.split(';')
    print(fun)

listexamples()

def scrapping():
    testfile = open('testfile.txt','r')
    for line in testfile:
        line = line.rstrip()
        if not line.startswith('From'):
            continue
        words = line.split()
        if words.__contains__('@'):
            print(words)

#scrapping()
# in to see something is in - is to return true or false

# Dictionaries

def dict1():
    purse = dict()
    #order is not maintained in the dictionaries
    purse['money'] = 1202902
    purse['candy'] = 3
    purse['keys'] = 1
    purse['tissues'] = 10
    print(purse)
    co = {}
    #counting number of elemets in a list
    names= ['csev', 'cwen', 'csev','zquian','cwen']
    for name in names:
        if name not in co:
            co[name] = 1 #key is name and value is 1
        else:
            co[name] = co[name]+1

    print(co)

    name = 'csev'
    if name in co: #this is what get method does
        x = co[name]
    else:
        x = 0
    print(x)

    for name in names:
         co[name] = co.get(name,0) +1 #in get function 0 is default
    # count number of words in a file

    linewords = {}
    line = "Hi. My name is Shreya Bhardwaj. I'm sure you know that by this time"
    words = line.split()
    for word in words:
        linewords[word] = linewords.get(word, 0)+1
    print(linewords)

    for key in linewords:
        print(key,linewords[key])

    list(linewords)
    print(list(linewords))
    print(linewords.keys())
    print(linewords.values())
    print(linewords.items())

    for i,j in linewords.items():
        print(i,j)
    
dict1()

#Tuples- ()- immutable- but lists are mutable- cannot use sort, append, reverse() in tuples
def tuples():

    x = ('glen','toit','grey')
    print(x[2])

    # we can put a tuple on left hand and assign items on right side
    (y,z) = (4,'dongle') # here, y will be 4 and z will be dongle

    #similarly we can compare as well
    print((0,6,7) < (1,5,9))# this returns true or false- only first item is compared
    print((0,1,2000)<(0,3,4)) # here second item is compared as well
    print(('jones', 'sally') < ('jones', 'sam'))

    #We can append list of tuples
    d = {'a':10, 'b':6, 'e': 8}
    print(sorted(d.items())) # sorted function will print tuples of dictionary IMPORTANT
    #sorted(iterable, key=None, reverse=False)
    #key can be a func
    f = list()
    for k,v in d.items():
        f.append((k,v)) #list of tuple
    print(f)
    f = sorted(f, reverse=True)
    print(f)
    Tuple1 = (0,1,2,3,4,3,2,3,2,1,3)
    res = Tuple1.count(3) # counts number of occ of any element
    print('Count of 3 in Tuple is:', res)
    #index() fucntion- return first occ of given element in a tuple
    res1 = Tuple1.index(3) # first occ of 3 is printed
    red1 = Tuple1.index(3,4,8)
    #here if slices the given tumple of 3,4,8 into 2 - 3 is the element and 4-8 is the position where you wnat to find the occ of 3 
    red = len(Tuple1)
  
tuples()

# find 10 most common words in a file
def script():
    count = {}
    fhand = open("file.txt")
    for line in fhand:
        line = line.rsplit()
        words = line.split()
        for word in words:
            count[word] = count.get(word,0) +1

    print(count)

    l = list() # list of tuples
    for k,v in count.items():
        tup = (v,k)
        l.append(tup)

    l = sorted(l, reverse=True)
    for k,v in l[:10]:
        print(k,v)
# this is called list comprehension- we make a list of tuples and sort it

# all functions in python are pass by reference- whatever we change in func is relfected back. Also the variables
#  are overwritten by local vars

def ref(mylist,x):
    print(mylist)
    x = 2 # this is local variable- gets destroyed
    print(x)
    mylist[2] = 40
    print(mylist)
    return
mylist = [10,20,70,50]
x =10
ref(mylist,x)
print(mylist)
print(x)

# in functions we can also pass a variable length variables
def printinfo(arg1, *varibletup):
    print(arg1)
    for var in varibletup:
        print(var)
printinfo(10,20,80,90,119)

#arg1 =
#sum = lambda arg1, agr2: arg1 + arg2
from array import *

arr = array('i',[2,4,5,6,7]) # i is integer
for i in arr:
    print(i)
for i in range(len(arr)):
    print(arr[i])
arr2 = array('u', ['q','e','t']) # u is unicode
print(arr2)
arr3 =array(arr.typecode, (a for a in arr)) # for loop in one line # typecode is integer here a.arrtype we are refering that
print(arr3)
i = 0
while i < len(arr3):
    print(arr3[i])
    i+=1

def prime1():
    x = 3
    while x != 0:
        x = int(input("input the number: "))
        for i in range(2,x):
            if x % i == 0:
                print("{} is not a prime number".format(x))
                break
        else:
            print("prime")
    

prime1()

def fact(y):

    if y == 0 or y ==1:
        return 1
    else:
        z = y * fact(y-1)
        return z
    print(z)

print(fact(7))

def fibo(n):
    z = []
    if n == 0:
        return 0
    if n == 1:
        return 1
    else:
        for i in range(n):
            if i == 0:
                z.append(0)
            elif i == 1:
                z.append(1)            
            else:
                z.append(z[i-1] + z[i-2])
        return z
print(fibo(20))

#sets- well defined objects- values cannot be repeated. Represented by {}
# sets are unchangable, order is not maintained
def setss():
    info = {"calso", 19, False, 5, 9, 19}
    print(info)
    har = {} # this will make empty dictionary
    hau = set()
    for val in info:
        print(val)
    
    s1 = {1, 2, 5, 6}
    s2 = {3, 6, 7}
    print(s1.union(s2))
    print(s1.intersection(s2))
    print(s1.symmetric_difference(s2)) #all values which are not common
    print(s1.isdisjoint(s2)) # returns flase as 6 is common- no commmon values in sets then prints true
    print(s1.issuperset(s2))
    print(s2.issubset(s1))
    print(s1.update(s2))

    s1.remove(2)
    s1.discard(9) # no error even if the element is not present
    item = s1.pop() # any element will be popped
    del s2 # s2 is deleted
    s1.clear # set is not dleeted, but values are cleared.
setss()

#ifelse shorthand
a = 330
b = 2203
print("A") if a > b else print("=") if a == b else print("B")
print(9) if a<b else ""
c = 9 if a<b else 0

#enumerate- Gives us index as well
index = 0
a = [12,45,67,89,90,98]
for mark in a:
    print(mark)
    if(index == 3):
        print("waah")
    index += 1

for idx, mark in enumerate(a):
    print(mark)
    if(idx == 3):
        print("waan")

#the index in emumarate starts with 0 but we can specify if we wish it to start from any other number
for ic, mk in enumerate(a, start=1):
    print(ic)

#How import works- * is not recommended
#  
import math
print(dir(math)) # all functions printed of math

# function of __if name == "main": is that when you import another program and that program is calling itself and you call the another script- twice run
#if the calling happens in main then the function will only be called if we directly run it- on importing it wont run

#local and global variables in python.
#variable in function cannot be used outside but variable outside function can be used  inside

g = 4
print(g)
def hello():
    # to change global g- use global keyword
    global g
    g = 10 
    f = 2   
    print(f"local {f}")

hello()
print(g)

#file handling

def fules():
    createfile = open('myfile.txt', 'x') # create mode
    createfile.write("Hello shreya, You are doing great. Im proud of you.")
    createfile.close()
    f = open('myfile.txt', 'r')
    text = f.read()
    print(text)
    f.close()

    #f = open("filename","rt") t means text file. if we write rb - b is binary
    with open('myfile.txt', 'a') as f:
        f.append("Hey again!")
        f.append("98,99,97")
        while True:
            line = f.readline()
            print(line)
            if not line:
                break
            m1 = line.split(",")[0]
            m2 = line.split(",")[1]
            m3 = line.split(",")[2]
            print(f"marks in eng {m1}")
            print(f"marks in maths {m2}")
            print(f"marks in science {m3}")

        f.readlines()
    f = open("myfile.txt","a")
    lines = ['line1 \n', 'line2\n', 'line3\n']
    f.writelines(lines)
    f.close()
    #seek() and tell() functions are used to work with the objects and their positions within a file.
    with open('testwkf.py', 'r') as g:
        g.seek(10) #move to the 10th byte of the file- meaning dont read the file from the start- rather 
        #move to the 10th byte(character)
        g.tell() # this tells us kaha tak seek kara hua h
        g.read(5) #read the next 5 bytes 
    #truncate(x)- mai chahti hu ki srif x bytes aaye file me after writing 
        g.write("#helloworld")
        g.truncate(5)
    
    #Lambda functions- anonymous function without a name. Used when a small function is required for a short period of time
    double = lambda x: x*2
    avg =  lambda x,y,z: (x+y+z)/3
    print(double(3))
    print(avg(2,4,6))
    #lambda func is used to pass a func as an argument to anpther func
    def appl(fx, value):
        return 6+ fx(value)
    appl(double,12)  
    appl(lambda: x*x*x, 2)  

    #Map, filter and reduce
    #These are built-in functions that allow you to apply a fucntion to a sequence of elements and return a new sequence. 
    #These are called higher-order functions, as they take other functions as arguments. 
    map:
    #The map function applies a fucntion to each element in the sequence and returns a new sequence containing 
    #the transformed elements. 
    map(function, iterable)

    def cube(x):
        return x*x*x
    lis = [1,2,4,6,7,8]
    newlis = list(map(cube, lis))

    filter:
    def filter_function(a):
        return a>4
    newnewl = filter(filter_function, lis) #filter func will retrun true or false- for the values it is printing true will come in the new list
    print(newnewl)

    kk = list(map(lambda x: x*x*x, lis))

    reduce:
    from functools import reduce
    numbers = [1,2,5,7]
    sum = reduce(lambda x,y: x+y, numbers)
    print(sum) # sum will be the sum of all numbers. 

#is vs '=='
is - compares exact location to location in the memory
== - compares values. 
a = 4
b = "4"

c = [1,3,43]
d = [1,3,43]
#Then also python created 2 diff lists

e = 3
f = 3
print(e is f) #- true - because when we make a contanst in python- it makes it once in memory. - any immutable object made more than once- will point to same memory postion.
print(e == f) #- true

    #oops

class Railwayform:
        name = "Shreya"
        age = "16"
        source = "Jaipur"
        destination = "London"
        seat_type = "1st class"
        def info(self):
            print(f"{self.name} is {self.age} years old") # self parameter is a reference to the current instance of the class and 
                                                    # with self you can use class varibales

a = Railwayform()
#a.name = "Katy"
print(a.name)
a.info()
b = Railwayform()
b.name = "Nikita"
b.age = "25"
b.info()

#Construtor- used to create and initialize an object of a class- automaticcaly invoked when class object is created. 
class Person:
    name = "Shreya"
    occ = "Devops Engineer"
    def info(self): # in every fucntion in class must have self arg as we refer the object with self on which we played the method
        print(f"{self.name} is a {self.occ}")

a = Person()
print(a.name)
a.info()
a.name = "Devya"
a.occ = "HR"
a.info()

class People:
    def __init__(self, n, o):
        #print("Hey person")
        self.name = n
        self.occ = o
    def info(self): # in every fucntion in class must have self arg.
        print(f"{self.name} is a {self.occ}")

a = People("Shreya", "Devops Engineer")
print(a.name)
a.info()
b = People("Duke", "HR")
b.info()
#
c =  People("ss","dd") #cant pass 3 args- only pass 2 here as self is passed automatically


#Decorators- one function taking some other function
#For example you have 50 functions- you want all of them to say hi in the start and bye in the end- use decorator

#In Python, functions are first class objects which means that functions in Python can be used or passed as arguments.

def greet(fx): #this is a decorator
    def mfx(*args, **kwargs): # * args take if any argument is present as tuples- **kwargs take arguments as dictionary if present
        print("Hii and welcome\n")
        fx(*args, **kwargs)
        print("Thanks for using this function!\n")
    return mfx


@greet
def hlo():
    print("What a day!\n")

@greet
def add(a,b):
    c = a+b
    print(c)

hlo()
#greet(hlo)() - use this if dont want to use @greet
add(5,6)

# greet function is useful is logging
import logging

def log_fucntion_call(func):
    def deco(*args, **kwargs):
        logging.info(f"calling {func.__name__} with args={args}, kwargs={kwargs}") #__name__ we access the name of the func
        result =  func(*args, **kwargs)
        logging.info(f"{func.__name__} returned {result}")
        return result
    return deco

@log_fucntion_call
def myfunc(a,b):
    return a+b

# getters and setters
class Myclass:
    def __init__(self, value):
        self._value = value
    
    def show(self):
        print(f"Value is {self._value}")
    
    @property #defualt decorator- makes getter
    def ten_value(self):
        return 10*self._value

    @ten_value.setter # setter
    def ten_value(self, new_value):
        self._value = new_value/10
    
obj = Myclass(5)
obj.show()
print(obj._value)
obj.ten_value = 98
print(obj.ten_value)
obj.show()

#Inheritance
class employee:
    def __init__(self, name, id):
        self.name = name
        self.id = id
    def showDetials(self):
        print(f"the name if the employee is {self.name} with id {self.id}")

class department(employee):
    def __init__(self, name, id, department):
        super().__init__(name, id)
        self.department = department

    def showDepartment(self):
        print(f"The department is {self.department}")

emp1 = department("shreya",169,"CS")
emp1.showDetials()
emp1.showDepartment()

#access specifiers in python
#No public, private and protected in python
class ggg:
    def __init__(self):
        self.name = "Harry"  # this is also accsible from outside- anything with self is public
        self.__age = "9" # THIS IS A PRIVATE VARIABLE AS IT IS PREFIXED BY __

a = ggg()
a.emp1 = 5 # public
#HOW TO ACCESS PRIVATE VARIABLE
print(a._ggg__age) #another _ in from of class and then __var - this is called name mangling
# name mangling- so that private variables of subclass and superclass cannot be accidental overwritten by subclass
print(a.__dir__()) # will print all methods of ggg glass

#Protected- vaiable accessible by private and protected class
class Student:
    def __init__(self):
        self._name = "Shreya"

    def _funName(self):      # protected method
        return "PythoncodingWithShreya"

class Subject(Student):       #inherited class
    pass

obj = Student()
obj1 = Subject()
print(dir(obj))

# calling by object of Student class
print(obj._name)      
print(obj._funName())     
# calling by object of Subject class
print(obj1._name)    
print(obj1._funName())

# static Methods: When we dont want class instance- We can call this static method without instance- why we need it? when we package this class and someone else imports it we want them to also be able to use this method
# you need to pass self arg in static method
class Mathx:
    def __init__(self, num):
        self.num = num
    def addtonum(self, n):
        self.num = self.num + n

    @staticmethod
    def add(a,b):
        return a+b
res = Mathx.add(1,2)
print(res)

# instance variable vs class variable
#class variables are defined at the class level and are shared amoung all instances of the class.
#Defined outside of any method and used to store info that is common to all instances of the class
# 
class Emp:
    companyName = "Apple"
    def __init__(self, name):
        self.name = name
    def showdetails(self):
        print(f"The name of the Employee is {self.name} of company {self.companyName}")
    
n = Emp("Shreya")
n.companyName = "Apple Paris"
n.showdetails() # the name changes for this instance
Emp.showdetails(n)
m = Emp("Rohan")
m.showdetails() # but the companyName remains same for as Apple for this instance
Emp.companyName = "Google" # this will change the companyName for other employees created after this statement.

#Class methods- above when we change a class variable - it only changes for that instance with n.companyname()
#But if we want to change something for the entire class- for every instance- we use class methods 
#Class methods are methods tied to the class and not instance
class Clsmeth:
    company = "Apple"
    def show(self):
        print(f"The name is {self.name} in company {self.company}")
    
    def changeCompany(cls, newCompany): # here cls is the class- we can write anything as the fist argument- itis considered as object
        cls.company = newCompany
    @classmethod
    def classm(cs, com):
        cs.company = com
e1 = Clsmeth()
e1.name = "Shreya"
e1.show()
e1.changeCompany("Tesla")
e1.show() #changes the company variable for the instance
print(Clsmeth.company)

# we can use class methods as alternative to constructors and make it format the data in the correct format and then pass that data to constructors
class metcons:
    def __init__(self, name, salary):
        self.name = name
        self.salary = salary
    @classmethod
    def fromStr(cls, string):
        return cls(string.split("-")[0], string.split[1])

e = metcons("Shreya", "3800000")
print(e.name)
print(e.salary)
string = "John-200000"
f = metcons(string.split("-")[0], string.split[1]) #not a very clean way. We can use class methods instead
g = metcons.fromStr(string)
print(g.name)
print(g.salary)

class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    @classmethod
    def from_string(cls, string):
        name, age = string.split(',')
        return cls(name, int(age))

person = Person.from_string("John Doe, 30")
print(person.name, person.age)

# dir, __dict__ and help() methods 
 #The dir() function returns a list of all the attributes and methods (including dunder(methods with __xyz__) methods) available for an object. It is a useful tool for discovering what you can do with an object
x = [1,2,3]
print(dir(x))
y = (1,3,5)
print(dir(y))

 #The __dict__ attribute returns a dictionary representation of an object's attributes. It is a useful tool for introspection. Example:

class Person:
  def __init__(self, name, age):
      self.name = name
      self.age = age
    
p = Person("John", 30)
print(p.__dict__) # all atrributes of the object p will be printed like- {'name': 'John', 'age': 30}

#The help() function is used to get help documentation for an object, including a description of its attributes and methods. Example:
print(help(Person))

#Super keyword- calling parent class methods from child class
#When a class inherits from a parent class, it can override or extend the methods defined in the parent class. However, sometimes you might want to use the parent class method in the child class.

class ParentClass:
    def parent_method(self):
        print("This is the parent method.")
class ChildClass(ParentClass):
    def child_method(self):
        print("This is the child method.")
        super().parent_method()
child_object = ChildClass()
child_object.child_method()


class p1:
    def parent_method(self):
        print("This is the p1 method.")
class C1(p1):
    def parent_method(self):
        print("This is the c1 parent method.")
        super().parent_method()
    def child_method(self):
        print("This is the c1 method.")
        super().parent_method()
c1_object = C1()
c1_object.child_method()
c1_object.parent_method() # Will call its own parent_method and inside it will call prent because of super

class p2:
    def parent_method(self):
        print("This is the p1 method.")
class C2(p2):
    def child_method(self):
        print("This is the c1 method.")
        super().parent_method()
c2_object = C2()
c2_object.child_method()
c2_object.parent_method() # here it will call parent class ka method as khud ka hai nhi.


#calling constructor of parent for code reusability. (Do not repeat logic)
class Employee:
  def __init__(self, name, id):
    self.name = name
    self.id = id

class Programmer(Employee):
  def __init__(self, name, id, lang):
    super().__init__( name, id)
    self.lang = lang

rohan = Employee("Rohan Das", "420")
harry = Programmer("Harry", "2345", "Python")
print(harry.name)
print(harry.id)
print(harry.lang)

#magic methods- __xyz__ - dunder methods
#These are special methods that you can define in your classes, and when invoked, they give you a powerful way to manipulate objects and their behaviour.

#Magic methods, also known as “dunders” from the double underscores surrounding their names, are powerful tools that allow you to customize the behaviour of your classes. 
# They are used to implement special methods such as the addition, subtraction and comparison operators, as well as some more advanced techniques like descriptors and properties.
#The init method is a special method that is automatically invoked when you create a new instance of a class. This method is responsible for setting up the object’s initial state, and it is where you would typically define any instance variables that you need. Also called "constructor", we have discussed this method already
#The str and repr methods are both used to convert an object to a string representation. The str method is used when you want to print out an object, while the repr method is used when you want to get a string representation of an object that can be used to recreate the object.
#The len method is used to get the length of an object. This is useful when you want to be able to find the size of a data structure, such as a list or dictionary.
# The call method is used to make an object callable, meaning that you can pass it as a parameter to a function and it will be executed when the function is called. This is an incredibly powerful tool that allows you to create objects that behave like functions.

#These are just a few of the many magic methods available in Python. They are incredibly powerful tools that allow you to customize the behaviour of your objects, and can make your code much cleaner and easier to understand. So if you’re looking for a way to take your Python code to the next level, take some time to learn about these magic methods.

class Employee:

  def __init__(self, name):
    self.name = name

  def __len__(self):
    i = 0
    for c in self.name:
      i = i + 1
    return i

  def __str__(self):
    return f"The name of the employee is {self.name} "

  def __repr__(self):
    return f"Employee('{self.name}')"

  def __call__(self, a, b):
    print(f"{a} + {b} = {a + b}")
    print("You are fired!")

e = Employee("Kunal")
print(str(e))
print(repr(e))
# print(e.name)
# print(len(e))

e("1", "1") # this will call __call__ 

#method overriding in object-oriented programming that allows you to redefine a method in a derived class. 
# The method in the derived(child) class is said to override the method in the base(parent) class. 
# When you create an instance of the derived class and call the overridden method, the version of the method in the derived(child) class is executed, rather than the version in the base class.
class Shape:
    def __init__(self, x, y):
        self.x = x
        self.y = y
    def area(self):
        return self.x * self.y

class Circle(Shape):
    def __init__(self, radius):
      self.radius = radius
      super().__init__(radius, radius)

    def area(self):
        return 3.14 *  super().area()

# rec = Shape(3, 5)
# print(rec.area())

c = Circle(5)
print(c.area())

# using os.rename, using os.listdir, os.path.splitext
# using pyPDF- we can merge, write, read, encrypt pdf files

#Operator overloading
#Operator Overloading is a feature in Python that allows developers to redefine the behavior of mathematical 
#and comparison operators for custom data types. 
# This means that you can use the standard mathematical operators (+, -, *, /, etc.) and comparison operators (>, <, ==, etc.) in your own classes, just as you would for built-in data types like int, float, and str.
class Vector:
    def __init__(self, i, j, k):
        self.i = i
        self.j = j
        self.k = k

    def __str__(self):
     return f"{self.i}i + {self.j}j + {self.k}k" # we can use fstring like this also
#here we are over loading add operator
    def __add__(self, x):
        # return f"{self.i + x.i}i,  {self.j+x.j}j, {self.k+x.k}k" # this returns a str type not a vector
        return Vector(self.i + x.i,  self.j+x.j, self.k+x.k) # for it to return a vector value use the constructor Vector
v1 = Vector(3, 5, 6)
print(v1)

v2 = Vector(1, 2, 9)
print(v2)

print(v1 + v2)
print(type(v1 + v2))

#You can overload an operator in Python by defining special methods in your class. These methods are identified by their names, which start and end with double underscores (__). 
# Here are some of the most commonly overloaded operators and their corresponding special methods:
 
# + : __add__
# - : __sub__
# * : __mul__
# / : __truediv__
# < : __lt__
# > : __gt__
# == : __eq__

#Single inheritance
#Single inheritance is a type of inheritance where a class inherits properties and behaviors from a single parent class. This is the simplest and most common form of inheritance.

class Animal:
    def __init__(self, name, species):
        self.name = name
        self.species = species
    def make_sound(self):
        print(f"Sound made by the animal")

class Cat:
    def __init__(self, name, breed):
        Animal.__init__(self, name, species="cat")
        self.breed = breed

    def make_sound(self): # this is overriding the parent class method
        print("meow") 

#multiple inheritance- one childclass can have multiple parent classes
class Emp:
    def __init__(self, name, empid):
        self.name = name
        self.empid = empid
    def show(self):
        print(f"The name is {self.name} with employee id {self.empid}")
        
class Dancer:
    def __init__(self, occupation):
        self.occ = occupation

   # def show(self):  # when we have this also and above show also, then the above show fucntion is called as Emp is the first parent class- if we reverse the way classes are inherited- then this how will be called 
    #    print(f"The occupation is {self.occ}")
        
class person(Emp,Dancer):
    def __init__(self, name, empid, occupation):
        Emp.__init__(self, name, empid)
        Dancer.__init__(self, occupation)
    #def show(self):
    #    print(f"The name is {self.name} with employee id {self.empid} and occupation {self.occ}")


o = person("Shivani", "123", "Kathak")
o.show()
print(person.mro()) # gives output like - [<class '__main__.person'>, <class '__main__.Emp'>, <class '__main__.Dancer'>, <class 'object'>]
#mro() function- method resolution order- to resolve conflicts between methods or attributes from different parent classes. 
# The MRO determines the order in which parent classes are searched for attributes and methods.

#Multilevel Inheritance
#Multilevel inheritance is a type of inheritance in object-oriented programming where a derived class inherits from another derived class. 
#This type of inheritance allows you to build a hierarchy of classes where one class builds upon another, leading to a more specialized class.
class Animal:
    def __init__(self, name, species):
        self.name = name
        self.species = species
        
    def show_details(self):
        print(f"Name: {self.name}")
        print(f"Species: {self.species}")
        
class Dog(Animal):
    def __init__(self, name, breed):
        Animal.__init__(self, name, species="Dog")
        self.breed = breed
        
    def show_details(self):
        Animal.show_details(self)
        print(f"Breed: {self.breed}")
        
class GoldenRetriever(Dog):
    def __init__(self, name, color):
        Dog.__init__(self, name, breed="Golden Retriever")
        self.color = color
        
    def show_details(self):
        Dog.show_details(self) # in the output we get all details becuase we are calling parents show_details also
        print(f"Color: {self.color}") 

#o = Dog("tommy", "Black")
o = GoldenRetriever("tommy", "Black")
o.show_details()
print(GoldenRetriever.mro())

#BaseClass, DerivedClass1, and DerivedClass2. The DerivedClass1 class inherits from the BaseClass, and the DerivedClass2 class inherits from the DerivedClass1 class. 
# This creates a hierarchy where DerivedClass2 has access to all the attributes and methods of both DerivedClass1 and BaseClass.

#hybrid and hierarchical inheritance

#Hybrid inheritance is a combination of multiple inheritance and single inheritance in object-oriented programming. 
# It is a type of inheritance in which multiple inheritance is used to inherit the properties of multiple base classes into a single derived class, and single inheritance is used to inherit the properties of the derived class into a sub-derived class.
class BaseClass1:
    pass
  # attributes and methods
class DerivedClass1(BaseClass1):
    pass
  # attributes and methods
class DerivedClass2(BaseClass1):
    pass

class DerivedClass(DerivedClass1, DerivedClass2):
  # attributes and methods
    pass
  #Hierarchical Inheritance is a type of inheritance in Object-Oriented Programming where multiple subclasses inherit from a single base class. In other words, a single base class acts as a parent class for multiple subclasses. 
  # This is a way of establishing relationships between classes in a hierarchical manner.

class Animal:
    def __init__(self, name):
        self.name = name
    def show_details(self):
        print("Name:", self.name)
class Dog(Animal):
    def __init__(self, name, breed):
        Animal.__init__(self, name)
        self.breed = breed
    def show_details(self):
        Animal.show_details(self)
        print("Species: Dog")
        print("Breed:", self.breed)
class Cat(Animal):
    def __init__(self, name, color):
        Animal.__init__(self, name)
        self.color = color
    def show_details(self):
        Animal.show_details(self)
        print("Species: Cat")
        print("Color:", self.color)

#using win32com 

# time module
import time
def whileloop():
    i = 0
    while i <50000:
        i =i + 1
      
def forloop():
    for i in range(50000):
        i = i+1
        

init = time.time()
whileloop()
t1 = time.time() - init 
print(f"time used by while loop {t1}")
forinit = time.time()
forloop()
print(f"time used by while loop {t1}")
print(f"time used by for loop {time.time()-forinit}")

time.sleep(3)
time.strtime() # function formats a time value as a string, based on a specified format. 
#This function is particularly useful for formatting dates and times in a human-readable format
t = time.localtime()
formatted_time = time.strftime("%Y-%m-%d %H:%M:%S", t)
print(formatted_time)

#creating command-line utility using argparse module- running a python script and giving diff options from command line to do diff things

import argparse

parser = argparse.ArgumentParser()

parser.add_argument("arg1", help="description of argument 1")
parser.add_argument("arg2", help="description of argument 2")
parser.add_argument("-o", "--optional", help="description of optional argument", default="default_value") # this is an optional argument
# Parse the arguments
args = parser.parse_args()
# Use the arguments in your code
print(args.arg1)
print(args.arg2)

#Watch 85 again 

#Warlus operator - added after python3.8
#allows you to assign a value to a variable within an expression. 
# This can be useful when you need to use a value multiple times in a loop, but don't want to repeat the calculation.
#The Walrus Operator is represented by the := syntax and can be used in a variety of contexts including while loops and if statements.
print(a:=False) #Assigning value to a within the print statement
numbers = [1, 2, 3, 4, 5]
while (n := len(numbers)) > 0:
    print(numbers.pop())

foods =list() #list constructor
while True:
    food = input("What food do you like?")
    if food == "quit":
        break
    foods.append(food)

#alternate way of writing this

while(food := input("What food you like? ")) != "quit": # assiging whatever input we get to food and if that is not quit go inside the loop
    foods.append(food)

#shutil module
import shutil
#Shutil is a Python module that provides a higher level interface for working with file and directories. 
#The name "shutil" is short for shell utility. It provides a convenient and efficient way to automate tasks that are commonly performed on files and directories.

#The following are some of the most commonly used functions in the shutil module:

#shutil.copy(src, dst): This function copies the file located at src to a new location specified by dst. If the destination location already exists, the original file will be overwritten.

#shutil.copy2(src, dst): This function is similar to shutil.copy, but it also preserves more metadata about the original file, such as the timestamp.

#shutil.copytree(src, dst): This function recursively copies the directory located at src to a new location specified by dst. If the destination location already exists, the original directory will be merged with it.

#shutil.move(src, dst): This function moves the file located at src to a new location specified by dst. This function is equivalent to renaming a file in most cases.

#shutil.rmtree(path): This function recursively deletes the directory located at path, along with all of its contents. This function is similar to using the rm -rf command in a shell.

shutil.copy("snakegame.py", "snakegame2.py")

#Request module
import requests
import json

response = requests.get("https://www.google.com")
print(response.text) # get is used to get data from some website

url = "https://jsonplaceholder.typicode.com/posts"
data = {
    "title": "Life",
    "body": "should make",
    "userID": "Sense"
}
headers =  {
    'Content-type': 'application/json; charset=UTF-8',
  }
resp = requests.post(url, headers=headers ,json=data) # to send data to some website

#News api- #News API is a simple HTTP REST API for searching and retrieving live articles from all over the web
# It can help you answer questions like:
    #What top stories is TechCrunch running right now?
    #What new articles were published about the next iPhone today?
    #Has my company or product been mentioned or reviewed by any blogs recently?
#You can search for articles with any combination of the following criteria:
    #Keyword or phrase. Eg: find all articles containing the word 'Microsoft'.
    #Date published. Eg: find all articles published yesterday.
    #Source domain name. Eg: find all articles published on thenextweb.com.
    #Language. Eg: find all articles written in English.


# Generators
#Generators in Python are special type of functions that allow you to create an iterable sequence of values. 
# A generator function returns a generator object, which can be used to generate the values one-by-one as you iterate over it. 
# Generators are a powerful tool for working with large or complex data sets, as they allow you to generate the values on-the-fly, rather than having to create and store the entire sequence in memory.
#In Python, you can create a generator by using the yield statement in a function. 
# The yield statement returns a value from the generator and suspends the execution of the function until the next value is requested
def my_generator():
    for i in range(5):
        yield i

gen = my_generator()
print(next(gen))
print(next(gen))
print(next(gen))
print(next(gen))
print(next(gen))
# Output:
# 0
# 1
# 2
# 3
# 4
# We can use a loop to generate the output
gen = my_generator()
for i in gen:
    print(i)
#One of the main benefits of generators is that they allow you to generate the values on-the-fly, rather than having to create and store the entire sequence in memory. 
#This makes generators a powerful tool for working with large or complex data sets, as you can generate the values as you need them, rather than having to store them all in memory at once.

#Fucntion caching- used when single function is running multiple times for same value
#Function caching is a technique for improving the performance of a program by storing the results of a function call so that you can reuse the results instead of recomputing them every time the function is called. 
# This can be particularly useful when a function is computationally expensive, or when the inputs to the function are unlikely to change frequently.
# done using functools module
#For example-
import functools
import time

@functools.lru_cache(maxsize=None)
def fib(n):
    time.sleep(5)
    return n*5

print(fib(20))
print(fib(5))
print(fib(6))
print(fib(20)) # these 3 values will be returned quickly without running the function again as the value is stored in cache
print(fib(5)) # funtion is memoized
print(fib(6)) # The vlaue is cahced in memory for one run- 
# Output: 6765 
#As you can see, the functools.lru_cache decorator is used to cache the results of the fib function. 
# The maxsize parameter is used to specify the maximum number of results to cache. 
# If maxsize is set to None, the cache will have an unlimited size.
#Example- ecommerce platform- home page products- instead of fetching it again ang again from db- store in cache

#Regular expressions
import re
pattern = ""
text = ""
match = re.search(pattern, text)
print(match) # retunrs true or false and stops on first occurance of the paatern found
pattern = r"[A-Z]+yclone" # r means raw string - so that the pattern are not treated as strings

# to get all occurances of the matched pattern words
matches = re.finditer(pattern,text)
for match in matches:
    print(match) # prints where the word is and what the word is
    print(type(match.span())) # span is a tuple
    print(text[match.span()[0]:match.span()[1]])

#AsyncIO
#It is not multithreading or multiprocessing- it is just a way of running multiple functions parallely
#making a function async using asyncio module
#typical execution of fucntions is that one finishes then second fucntions starts executing-
import time
import asyncio 
import requests


async def function1():
  print("func 1") 
  URL = "https://wallpaperaccess.in/public/uploads/preview/1920x1200-desktop-background-ultra-hd-wallpaper-wiki-desktop-wallpaper-4k-.jpg"
  response = requests.get(URL)
  open("instagram.ico", "wb").write(response.content)
   
  return "Harry"
  
async def function2():
  print("func 2") 
  URL = "https://p4.wallpaperbetter.com/wallpaper/490/433/199/nature-2560x1440-tree-snow-wallpaper-preview.jpg"
  response = requests.get(URL)
  open("instagram2.jpg", "wb").write(response.content)
  
async def function3():
  print("func 3")
  URL = "https://c4.wallpaperflare.com/wallpaper/622/676/943/3d-hd-wikipedia-3d-wallpaper-preview.jpg"
  response = requests.get(URL)
  open("instagram3.ico", "wb").write(response.content)

async def main():
  # await function1() # await makes them run one by one
  # await function2()
  # await function3()
  # return 3
  L = await asyncio.gather(
        function1(),
        function2(),
        function3(),
    )
  print(L)
  # task = asyncio.create_task(function1())
  # # await function1()
  # await function2()
  # await function3()

asyncio.run(main())

#Multi-threading
# using threading module
import threading
import time

def print_numbers():
    for i in range(5):
        print(i)
        time.sleep(1)

def print_letters():
    for letter in 'ABCDE':
        print(letter)
        time.sleep(1)

# Create threads
thread1 = threading.Thread(target=print_numbers)
thread2 = threading.Thread(target=print_letters)

# Start threads
thread1.start()
thread2.start()

# Wait for threads to finish
thread1.join()
thread2.join()

print("Threads have finished executing.")

#multiprocessing functions:
multiprocessing.Process(target, args): This function creates a new process that runs the target function with the specified arguments.

multiprocessing.Pool(processes): This function creates a pool of worker processes that can be used to parallelize the execution of a function across multiple input values.

multiprocessing.Queue(): This function creates a queue that can be used to communicate data between processes.

multiprocessing.Lock(): This function creates a lock that can be used to synchronize access to shared resources between processes.

from multiprocessing import Pool
def process_task(task):
    # Do some work here
    print("Task processed:", task)
if __name__ == '__main__':
    tasks = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    with Pool(processes=4) as pool:
        results = pool.map(process_task, tasks)


def producer(queue):
    for i in range(10):
        queue.put(i)
def consumer(queue):
    while True:
        item = queue.get()
        print(item)
queue = multiprocessing.Queue()
p1 = multiprocessing.Process(target=producer, args=(queue,))
p2 = multiprocessing.Process(target=consumer, args=(queue,))
p1.start()
p2.start()

def increment(counter, lock):
    for i in range(10000):
        lock.acquire()
        counter.value += 1
        lock.release()
if __name__ == '__main__':
    counter = multiprocessing.Value('i', 0)
    lock = multiprocessing.Lock()
    p1 = multiprocessing.Process(target=increment, args=(counter, lock))
    p2 = multiprocessing.Process(target=increment, args=(counter, lock))
    p1.start()
    p2.start()
    p1.join()
    p2.join()
    print("Counter value:", counter.value)
SonarQube
Argo CD, Flux CD